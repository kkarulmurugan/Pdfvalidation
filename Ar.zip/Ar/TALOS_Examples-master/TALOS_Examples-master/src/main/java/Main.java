import dd.automation.CustomActions.CompareTextInPDF_ByCoordinates;
import dd.automation.testCases.Toyota.carLOS_flow1;
import dd.automation.utilities.DriverHandler;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try{
			// Call DemoQARegistration script
			//DemoQARegistration demoQARegistration = new DemoQARegistration("Chrome");
			//GoogleSearch googleSearch = new GoogleSearch("Firefox");
			//navigation_5 carlos = new navigation_5();
			carlos_f1();
			//Signatures sign = new Signatures("Chrome");
			//String[] arguments = new String[]{"CodePen", "Dealer", "A", "C:\\Users\\deyanid\\Documents\\Flows\\images"};
			//sign.PerformAction(arguments);
			//sign.Close();
			//ToolsQAPractice toolsQA = new ToolsQAPractice("IE");
			//.
			//.
			//.
			//.
			
		}catch(Exception e){
			System.out.println(e.getMessage() + "Main error.");
		}
	}

	private static void carlos_f1() throws InterruptedException {
		carLOS_flow1 c1 = new carLOS_flow1("IE");
		c1.PerformAction();

	}

	private  static void CompareTxtInPDFByCoordinates(){
		// 1. Tell which Driver to use
		DriverHandler driverHandler = new DriverHandler("Chrome");
		WebDriver driver = driverHandler.getDriverHandler();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		CompareTextInPDF_ByCoordinates comparisson = new CompareTextInPDF_ByCoordinates();
		comparisson.Execute(driver, new String[] {"pdfPath1","DT_DATA1","DT_DATA2","DT_DATA3"});
	}
}

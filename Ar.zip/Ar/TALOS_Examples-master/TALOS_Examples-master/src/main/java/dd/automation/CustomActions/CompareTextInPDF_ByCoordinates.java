package dd.automation.CustomActions;

////<Mandatory_libraries>
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.openqa.selenium.WebDriver;
import stmJava.ActionResult;



//</Mandatory_libraries>
// Additional libraries might be declared here

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


//<This_lines_must_not_be_modified>
public class CompareTextInPDF_ByCoordinates extends ActionResult
{
    File file;
    PDDocument document;
    String comments;

    //</This_lines_must_not_be_modified>
    //<Mandatory_lines>
    public ActionResult Execute(WebDriver driver, String[] inputValue) //replace WebDriver by AndroidDriver for mobile actions
    {
        //Example call from Custom Action
        //PDFPath.pdf,Data1ToSearch,Data2ToSearch,Data3ToSearch,Data4ToSearch

        ActionResult actionResult = new ActionResult();
        actionResult.status = false;
        actionResult.comments =  "";
        String pdfPath = "";
        String[] arrayInput = inputValue;// inputValue.split("~");
        pdfPath = arrayInput[0] ;
        List<String> textToCompare;
        String findTitle;
        int pointX;
        int pointY;
        int width;
        int height;

        //</Mandatory_lines>
        ///////////////WORKSPACE START////////////////////////////////////////////////////////////////////////////////////////
        try{

            this.file = new File(pdfPath);
            this.document = PDDocument.load(file);

            // Validate Lease Date
            findTitle = "Lease Date:";
            pointX = 401; pointY = 60; width = 67; height = 8;
            List<String> expectedText = new ArrayList<String>();
            expectedText.add(arrayInput[1]);

            PDFValidation(actionResult, findTitle, expectedText, pointX, pointY, width, height);


            findTitle = "1. Parties";
            pointX = 48; pointY = 77; width = 518; height = 52;
            expectedText = new ArrayList<String>();
            expectedText.add("LESSEE AND CO-LESSEE NAME AND LESSEE’S BILLING ADDRESS");
            expectedText.add(arrayInput[2]);
            expectedText.add(arrayInput[3]);
            expectedText.add(arrayInput[4]);
            PDFValidation(actionResult, findTitle, expectedText, pointX, pointY, width, height);


            actionResult.comments = this.comments;
            actionResult.setPath(pdfPath);

        }
        catch(Exception ex){
            actionResult.comments = ex.getMessage();
            actionResult.status = false;
        }

        return actionResult;
    }

    private  void PDFValidation(ActionResult actionResult, String findTitle, List<String> textToCompare, int pointX, int pointY, int width, int height){
        try{
            Rectangle rect = new Rectangle(pointX, pointY, width, height); //coordinates of region

            PDPageTree allPages = document.getDocumentCatalog().getPages();

            String textExists = "";
            int startPage = 1;
            boolean found = true;
            for(PDPage page : allPages){
                if(TitleExistInPage(document, startPage, findTitle)) {
                    String findTextInPDF = VerifyText(page, "r"+startPage, rect, textToCompare);
                    if (findTextInPDF.isEmpty()){
                        this.comments = this.comments + "Text not found : " + textToCompare;
                        found = false;
                    }
                    else {
                        this.comments = this.comments + "\n" + findTextInPDF;
                        actionResult.status = true;
                    }

                    break;
                }
                startPage ++;
            }

            actionResult.status = actionResult.status && found;
        }catch (Exception ex){
            this.comments = ex.getMessage();
            actionResult.status = false;
        }

    }
    private boolean TitleExistInPage(PDDocument document, int pageNumber, String findTitle) throws IOException {
        PDFTextStripper stripper = new PDFTextStripper();
        stripper.setStartPage(pageNumber);
        stripper.setEndPage(pageNumber);

        String text = stripper.getText(document);

        String pageStr = String.format("page %d:", pageNumber);
        //System.out.println(pageStr);

        if(text.contains(findTitle))
            return true;


        return false;
    }
    private String VerifyText(PDPage page, String rectName, Rectangle rect, List<String>expectedText) throws IOException {
        PDFTextStripperByArea stripper = new PDFTextStripperByArea();

        stripper.setSortByPosition(true);

        stripper.addRegion(rectName, rect);

        stripper.extractRegions(page);

        // System.out.println("Rectangle dimensions:" + rect);
        List<String> copyExpectedText = TextCompare( expectedText,stripper.getTextForRegion(rectName));
        if(copyExpectedText.size() > 0)
            return "Text found: \n" +  Arrays.toString(copyExpectedText.toArray());
        else
            return "";
    }

    private List<String> TextCompare(List<String> expected, String actual){
        // split by new line
        int count = 1;
        String[] lines = actual.split("\\r?\\n");
        boolean containsActual = false;
        List<String> actualText = new ArrayList<String>();
        for (String line : lines) {
            line = line.trim();
            System.out.println("line " + count++ + " : " + line);
            containsActual = false;
            for(int expectedLine = 0; expectedLine < expected.size(); expectedLine ++) {
                if (expected.get(expectedLine).compareTo(line) == 0) {
                    containsActual = true;
                    actualText.add(expected.get(expectedLine));
                    expected.remove(expectedLine);
                    break;
                }
            }

            if (!containsActual)
                return new ArrayList<String>();
        }

        return actualText;

    }

}
//</Mandatory_lines>
package dd.automation.testCases;

import dd.automation.utilities.DriverHandler;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;

// ==========================================================================
// AUTHOR     : © Hexaware Technologies
// CREATE DATE     : 9/27/2019 3:33:31 PM
// SPECIAL NOTES: Created by Hexaware TALOS solution
// http://www.hexaware.com
// ==========================================================================
public class SignatureText
{
    WebDriver driver;
    WebElement elementCanvas;
    WebElement elementClear;
    WebDriverWait waitVar;
    private int timeOut = 30000;

    public SignatureText(String driverName) throws InterruptedException {
        // 1. Tell which Driver to use
        DriverHandler driverHandler = new DriverHandler(driverName);

        // Releasing the driver
        // Start the browser
        driver = driverHandler.getDriverHandler();
        waitVar = new WebDriverWait(driver, 30000);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

	/*
	public class Coords {

		private final  int x;
		private final int y;

		public Coords(int x,int y ) {
			this.y = y;
			this.x = x;
		}
	}
*/

    /*
        Param1: String parentFrame
        Param2: String elementId
        Param3: String primarySignature
        Param4: String identifier
        Param5: String path
     */
    public void PerformAction(String[] args){
        try {
            //Step: 1
            //https://codepen.io/kunukn/pen/kkbNvx
            //https://codepen.io/yguo/pen/OyYGxQ
            //driver.navigate().to("https://jsfiddle.net/szimek/jq9cyzuc/");
            driver.navigate().to("https://codepen.io/kunukn/pen/kkbNvx");

            String parentFrame = args[0];
            String elementId;
            String primarySignature = args[1];
            String identifier = args[2];

            //CodePen,signature-pad,Dealer,A
            By byId = By.id("signature-pad");
            String[] cElementId = ((By.ById) byId).toString().split(":");
            elementId = cElementId[1].trim();
            String path = args[3].length() > 0 ? args[3] + "\\" + elementId + ".png" : "";

            WebElement frame = null;
            //By signing here, I the Applicant, acknowledge that I have read and agree to the Terms and Conditions
            if(parentFrame.length() > 0) {
                frame = driver.findElement(By.name(parentFrame));
                driver.switchTo().frame(parentFrame);
            }

            elementCanvas = driver.findElement(By.id(elementId));

            Actions builder = new Actions(driver);
            Action drawAction = builder.moveToElement(elementCanvas,135,15) //start points x axis and y axis.
                    .clickAndHold()
                    .moveByOffset(200, 60) // 2nd points (x1,y1)
                    //.click()
                    .moveByOffset(100, 70)// 3rd points (x2,y2)
                    .doubleClick()
                    .build();
            drawAction.perform();




            String javascript = "var c = document.getElementById('" + elementId + "');\n" +
                    "if(c.getContext!=null)\n" +
                    "{\n" +
                    "    var ctx = c.getContext(\"2d\");\n" +
                    "    var lenCanvas = c.width * 80 / 100;\n" +
                    "    var signatureText = \""+ primarySignature + "\";\n" +
                    "    var unique = \"" + identifier + "\";\n" +
                    "    var togetherLen = signatureText.length + unique.length;\n" +
                    "    var spread = Math.round(lenCanvas / togetherLen) - 1;\n" +
                    "    var sprd = spread;\n" +
                    "    var completeText = signatureText + unique;\n" +
                    "}\n" +
                    "ctx.font = \"20px Lucida Handwriting\";\n" +
                    "for (var i = 0; i < completeText .length; i++) {\n" +
                    " ctx.fillText(completeText.charAt(i), sprd , c.height/2);\n" +
                    " sprd = sprd + spread;\n" +
                    "}";

            JavascriptExecutor js = (JavascriptExecutor)driver;
            js.executeScript(javascript);

            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

            // take screenshot
            if(path.length() > 0)
            {
                driver.switchTo().defaultContent();
                wait(2);
                driver.switchTo().frame(parentFrame);
                wait(2);
                elementCanvas = driver.findElement(By.id(elementId));

                if(elementCanvas != null) {
                    // Get entire page screenshot
                    driver.switchTo().defaultContent();
                    File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
                    BufferedImage fullImg = ImageIO.read(screenshot);

                    // cropping the image based on rect.
                    BufferedImage frmImage = null;
                    if(frame!= null) {
                        frmImage = fullImg.getSubimage(frame.getLocation().getX(), frame.getLocation().getY(),
                                frame.getSize().getWidth(), frame.getSize().getHeight());
                    }

                    BufferedImage eleScreenshot;
                    driver.switchTo().frame(parentFrame);
                    // Get the Width and Height of the WebElement using
                    int eleWidth = elementCanvas.getSize().getWidth();
                    int eleHeight = elementCanvas.getSize().getHeight();

                    // Get the Location of WebElement in a Point.
                    // This will provide X & Y co-ordinates of the WebElement
                    Point p = elementCanvas.getLocation();

                    // if image is into a frame
                    if (frmImage == null) {
                        eleScreenshot = fullImg.getSubimage(p.getX(), p.getY(),
                                eleWidth, eleHeight);
                    }else{
                        eleScreenshot = frmImage.getSubimage(p.getX(), p.getY(),
                                eleWidth, eleHeight);
                    }

                    ImageIO.write(eleScreenshot, "png", screenshot);

                    // Copy the element screenshot to disk
                    File screenshotLocation = new File(path);
                    FileUtils.copyFile(screenshot, screenshotLocation);
                }
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());

        }
    }


    private void Wait(int parseInt) throws InterruptedException {
        Thread.sleep(parseInt*1000);
    }

    /*
    private void draw_lines(Actions action, WebElement element, List<Coords>  offsets,  int scale) {
        //action.clickAndHold(element).perform();
        //builder.moveByOffset(0, 50).perform();
        //builder.moveByOffset(50, 0).perform();
        //builder.moveToElement(elementCanvas).perform();
        for (Coords o : offsets){

            action.clickAndHold(element);
            action.moveByOffset(scale * o.x, scale * o.y);
            action.release().perform();
        }
    }

    private void draw_lines(Actions action, WebElement element, List<Coords> offsets) {
        draw_lines(action, element, offsets, 1);
    }
*/
    public void Close() {
        driver.quit();
    }
}
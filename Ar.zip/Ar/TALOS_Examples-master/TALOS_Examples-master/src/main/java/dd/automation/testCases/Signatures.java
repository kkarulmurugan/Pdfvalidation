package dd.automation.testCases;

import dd.automation.utilities.DriverHandler;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;
// ==========================================================================
// AUTHOR     : © Hexaware Technologies
// CREATE DATE     : 9/27/2019 3:33:31 PM
// SPECIAL NOTES: Created by Hexaware TALOS solution
// http://www.hexaware.com
// ==========================================================================
public class Signatures
{
	WebDriver driver;
	WebElement elementCanvas;
	WebElement elementClear;
	WebDriverWait waitVar;
	private int timeOut = 30000;

	public Signatures(String driverName) throws InterruptedException {
		// 1. Tell which Driver to use
		DriverHandler driverHandler = new DriverHandler(driverName);

		// Releasing the driver
		// Start the browser
		driver = driverHandler.getDriverHandler();
		waitVar = new WebDriverWait(driver, 30000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*
	public class Coords {

		private final  int x;
		private final int y;

		public Coords(int x,int y ) {
			this.y = y;
			this.x = x;
		}
	}
*/

	/*
		Param1: String parentFrame
		Param2: String elementId
		Param3: String primarySignature
		Param4: String identifier
		Param5: String path
	 */
	public void PerformAction(String[] args){
		try {
			//Step: 1
			//https://codepen.io/kunukn/pen/kkbNvx
			//https://codepen.io/yguo/pen/OyYGxQ
			//driver.navigate().to("https://jsfiddle.net/szimek/jq9cyzuc/");
			driver.navigate().to("https://codepen.io/kunukn/pen/kkbNvx");

			String parentFrame = args[0];
			String elementId;
			String primarySignature = args[1];
			String identifier = args[2];

			//CodePen,signature-pad,Dealer,A
			By byId = By.id("signature-pad");
			String[] cElementId = ((By.ById) byId).toString().split(":");
			elementId = cElementId[1].trim();
			String path = args[3].length() > 0 ? args[3] + "\\" + elementId + ".png" : "";

			WebElement frame = null;
			//By signing here, I the Applicant, acknowledge that I have read and agree to the Terms and Conditions
			if(parentFrame.length() > 0) {
				frame = driver.findElement(By.name(parentFrame));
				driver.switchTo().frame(parentFrame);
			}

			elementCanvas = driver.findElement(By.id(elementId));

			Actions builder = new Actions(driver);
			/*Action drawOnCanvas=builder
					.moveToElement(elementCanvas)
					.moveToElement(elementCanvas,8,8)
					.clickAndHold(elementCanvas)
					.moveByOffset(120, 120)
					.moveByOffset(60,70)
					.moveByOffset(-140,-140)
					.release(elementCanvas)
					.build();
			drawOnCanvas.perform();
*/


			builder.clickAndHold(elementCanvas).moveByOffset(10, 50).
					//moveByOffset(50,10).
					//moveByOffset(-10,-50).
					moveByOffset(10,-50).release().perform();

			builder.clickAndHold(elementCanvas).moveByOffset(10, 50).
					//moveByOffset(50,10).
					//moveByOffset(-10,-50).
							moveByOffset(200,-20).release().perform();


			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		}catch (Exception ex){
			System.out.println(ex.getMessage());

		}
	}


	private void Wait(int parseInt) throws InterruptedException {
        Thread.sleep(parseInt*1000);
	}

	/*
	private void draw_lines(Actions action, WebElement element, List<Coords>  offsets,  int scale) {
		//action.clickAndHold(element).perform();
		//builder.moveByOffset(0, 50).perform();
		//builder.moveByOffset(50, 0).perform();
		//builder.moveToElement(elementCanvas).perform();
		for (Coords o : offsets){

			action.clickAndHold(element);
			action.moveByOffset(scale * o.x, scale * o.y);
			action.release().perform();
		}
	}

	private void draw_lines(Actions action, WebElement element, List<Coords> offsets) {
		draw_lines(action, element, offsets, 1);
	}
*/
	public void Close() {
		 driver.quit();
	}
}
package dd.automation.testCases.Toyota;

import dd.automation.utilities.DriverHandler;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Set;
import java.util.concurrent.TimeUnit;


public class carLOS_flow1 extends DriverHandler{
    WebDriver driver;
    WebElement elementCanvas;
    WebElement elementClear;
    WebDriverWait waitVar;
    private int timeOut = 30000;

    public carLOS_flow1(String driverName) throws InterruptedException {
        // 1. Tell which Driver to use
        DriverHandler driverHandler = new DriverHandler(driverName);

        // Releasing the driver
        // Start the browser
        driver = driverHandler.getDriverHandler();
        waitVar = new WebDriverWait(driver, 30000);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


    }

    public void PerformAction(){
        WebElement element = null;
        String value = "";
        try {
            //Step: 1
             driver.navigate().to("https://tfse-login-test.lending.fiservapps.com/00");
             element = driver.findElement(By.name("UserName"));
             element.sendKeys("deyanirad");

             element = driver.findElement(By.id("enteruser-continue-button"));
             element.click();

             element= waitVar.until(ExpectedConditions.presenceOfElementLocated(By.id("VerifyButton")));
             element.click();

            element= waitVar.until(ExpectedConditions.presenceOfElementLocated(By.id("Password")));
            element.sendKeys("Hexaware123");

            element= waitVar.until(ExpectedConditions.presenceOfElementLocated(By.id("enterpassword-login-button")));
            element.click();

            Wait(20);
            //Step: 13
            String currWin = "";
            int i = 0;
            value = "Loan Origination System 5.0";
            try{currWin = driver.getWindowHandle();}
            catch(Exception ex){currWin = null;}
            boolean titleFound = false;
            Set<String> handles = driver.getWindowHandles(); // get all window handles
            String windowChild;

            if (currWin != null)
                handles.remove(currWin);

            for (String winHandle : handles) {
                if (currWin == null || winHandle != currWin) {
                    windowChild = winHandle; // Storing handle of second window handle
                    driver = driver.switchTo().window(windowChild);
                    Thread.sleep(2000);
                    try {
                        if (driver.getTitle().startsWith(value)) {
                            titleFound = true;
                            break;
                        }
                        else
                        if (i == Integer.parseInt(value)) {
                            titleFound = true;
                            break;
                        }
                    }catch(Exception ex){}
                }

                i++;
            }


           // element = driver.findElement(By.xpath("/html/body/form[1]/div"));
            element = null;
            //waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//td/nobr[text()=('Credit Processing')]")));
            element = driver.findElement(By.xpath("//td/nobr[text()=('Credit Processing')]"));
            element.click();


            //Step: 15
            try {
                element = null;
                waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//td/nobr[text()='Search']")));
                element = driver.findElement(By.xpath("//td/nobr[text()='Search']"));
                element.click();
            }
            catch (Exception ex){}

            //Step: 16
            driver = driver.switchTo().frame("clientArea");

            //Step: 18
            element = null;
            try{
               // waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[ends-with(@class, 'txtSearchFor')]")));
               // try{element = driver.findElement(By.xpath("//input[@editId='ctl00_cphId_pnlSrchCrit_igtxtSearchFor']"));}catch (Exception e){}

                element = driver.findElement(By.id("igtxtctl00_cphId_pnlSrchCrit_igtxtSearchFor"));
                element.sendKeys("1308");

                element = driver.findElement(By.id("ctl00_cphId_pnlSrchCrit_btnCompany__5"));
                element.click();

                element = driver.findElement(By.id("ctl00_cphId_igWbTbContract_frame0"));
                driver = driver.switchTo().frame(element);
                Wait(2);
                element = driver.findElement(By.xpath("//table/tbody/tr[1]/td[2]/nobr/a"));
                String nameCredit = element.getText();

                element = driver.findElement(By.xpath("//table[substring(@id, string-length(@id) - string-length('DealStructure') +1) = 'DealStructure']/tbody/tr/td[@title='Net Capitalized Cost']/following-sibling::td[1]/nobr"));
                System.out.println(element.getText());

                // click desicion
                driver = driver.switchTo().defaultContent();
                driver = driver.switchTo().frame("clientArea");

                //
                element = driver.findElement(By.xpath("//div[@class='ClientMainContainer']//table/tbody/tr/td[text()='Decision']"));
                element.click();


                driver = driver.switchTo().frame(driver.findElement(By.id("ctl00_cphId_EDCR_frame0")));
                element = driver.findElement(By.xpath("//span[substring(@id, string-length(@id) - string-length('_fcLblDecision') +1) = '_fcLblDecision']"));
                if(element.getText() == "Decision")
                    System.out.println("Decision found");

                element = driver.findElement(By.xpath("//table[@id='ctl00_cphId_dd_ctl00_ds']/tbody/tr/td[substring(@id, string-length(@id) - string-length('_content') +1) = '_content']//tr/td/span[substring(@id, string-length(@id) - string-length('_fcLblAmtFinancedOrig') +1) = '_fcLblAmtFinancedOrig']"));
                System.out.println(element.getText());

                element = driver.findElement(By.xpath("//table[@id='ctl00_cphId_dd_ctl00_ds']/tbody/tr/td[substring(@id, string-length(@id) - string-length('_content') +1) = '_content']//tr/td/input[substring(@id, string-length(@id) - string-length('_fcLblTerm') +1) = '_fcLblTerm']"));
                System.out.println(element.getAttribute("value"));

        //todo decision


                element = driver.findElement(By.xpath("//td[substring(@id, string-length(@id) - string-length('btnSplHandCancel') + 3) = 'btnSplHandCancel']"));
                element.click();


            }
            catch (Exception ex){
                System.out.println(ex.getMessage());
            }

            //
            //super.Close(driver);
        }catch (Exception ex){

            System.out.println(ex.getMessage());

        }finally {
            driver = driver.switchTo().defaultContent();
            element = driver.findElement(By.xpath("//img[@alt='Start New Search']"));
            element.click();

            driver.findElement(By.id("spanLogoff")).click();

            driver.quit();
        }
    }


    private void Wait(int parseInt) throws InterruptedException {
        Thread.sleep(parseInt*1000);
    }


}

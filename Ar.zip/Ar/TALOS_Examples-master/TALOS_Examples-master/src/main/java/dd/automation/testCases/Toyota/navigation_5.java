package dd.automation.testCases.Toyota;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

// ==========================================================================
// AUTHOR     : © Hexaware Technologies
// CREATE DATE     : 9/27/2019 3:33:31 PM
// SPECIAL NOTES: Created by Hexaware TALOS solution
// http://www.hexaware.com
// ==========================================================================
public class navigation_5
{
	WebDriver driver;
	WebElement element;
	WebDriverWait waitVar;
	private int timeOut = 30000;

	public navigation_5() throws InterruptedException {
		String _driverPath = "C:\\Temp\\JavaCABuild\\Drivers\\IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver", _driverPath);



		driver = new InternetExplorerDriver();
		waitVar = new WebDriverWait(driver, 30000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

// STARTS BODY SECTION - PLEASE ADD YOUR CODE FOR ITERATE VALUES. (FOR, WHILE)
// ----------------------------------------------------
		//Step: 1
				driver.navigate().to("https://tfse-login-test.lending.fiservapps.com/00");





		/* ============= Skipped Step =============
		 Step: 2
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.cssSelector("img[class='f-logo']")));
element = driver.findElement(By.cssSelector("img[class='f-logo']"));
String border;
border = "#f00 solid 5px";
((JavascriptExecutor) driver).executeScript(
"arguments[0].style.outline = '" + border + "';", element);

		 ======================================== */
		//Step: 3
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("UserName")));
element = driver.findElement(By.id("UserName"));
element.sendKeys("deyanirad");


		//Step: 4
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("enteruser-continue-button")));
element = driver.findElement(By.id("enteruser-continue-button"));
element.click();


		//Step: 5
				this.Wait(Integer.parseInt("2"));



		//Step: 6
				waitVar = new WebDriverWait(driver,0);
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("image-verification")));


		//Step: 7
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("VerifyButton")));
element = driver.findElement(By.id("VerifyButton"));
element.click();


		//Step: 8
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("Password")));
element = driver.findElement(By.id("Password"));
element.sendKeys("Hexaware123");


		//Step: 9
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.id("enterpassword-login-button")));
element = driver.findElement(By.id("enterpassword-login-button"));
element.click();


		//Step: 10
		this.Wait(Integer.parseInt("2"));



		/* ============= Skipped Step =============
		 Step: 11
					element = null;
waitVar.until(ExpectedConditions.elementToBeClickable(By.cssSelector("role")));
element = driver.findElement(By.cssSelector("role"));
element.click();

		 ======================================== */
		//Step: 12
				Wait(5);



		//Step: 13
		String currWin = "";
		for (String winHandle : driver.getWindowHandles())
		{
			driver.switchTo().window(winHandle);
			if (driver.getTitle().startsWith("Loan Origination System 5.0"))
			{

				break;
			}
		}


		//Step: 14
		element = null;
		waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//td/nobr[text()=('Credit Processing')]")));
		element = driver.findElement(By.xpath("//td/nobr[text()=('Credit Processing')]"));
		element.click();


	//Step: 15
		try {
			element = null;
			waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//td/nobr[text()='Search']")));
			element = driver.findElement(By.xpath("//td/nobr[text()='Search']"));
			element.click();
		}
		catch (Exception ex){}

		//Step: 16
		driver.switchTo().frame("clientArea");

		//Step: 18
		element = null;
		try{
		waitVar.until(ExpectedConditions.elementToBeClickable(By.id("igtxtctl00_cphId_pnlSrchCrit_igtxtSearchFor")));
		element = driver.findElement(By.id("igtxtctl00_cphId_pnlSrchCrit_igtxtSearchFor"));
		element.sendKeys("1308");


		}
		catch (Exception ex){}

		element = null;
		try{
			element = null;
			waitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@ig_b='ctl00_cphId_pnlSrchCrit_btnCenter']")));
			element = driver.findElement(By.xpath("//table[@ig_b='ctl00_cphId_pnlSrchCrit_btnCenter']"));
			element.click();

			try{
				//driver.switchTo().defaultContent();

				//element = null;
				//waitVar.until(ExpectedConditions.elementToBeClickable(By.className("ClientFrame")));
				//element = driver.findElement(By.className("ClientFrame"));

				//driver.switchTo().frame(element);

				String r = "^(\\d_)+(\\d)$";
				Pattern re = Pattern.compile(r);
				String value = "0_1_1";
				if (re.matcher(value).matches()) {
					String[] indexes = value.substring(0, value.length()).split("_");
					for (String index : indexes) {
						int frameNum = Integer.parseInt(index);

						driver.switchTo().frame(frameNum);
					}
				} else {
					// driver.switchTo().defaultContent();
					driver.switchTo().frame(value);
				}

			}catch (Exception ex){}

			try {
				driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@id, 'ApplicationSummary')]")));
			}catch (Exception ex){}

			try{
			element = driver.findElement(By.xpath("//tr[contains(@id,'PartyDemographics')]/td[@title='Name']"));
		element.getAttribute("iDV");
			}catch (Exception ex){}




		}
		catch (Exception ex){}



		//Step: 22
		//driver.quit();




// ENDS BODY SECTION
// ----------------------------------------------------

	}

    private void Wait(int parseInt) throws InterruptedException {
        Thread.sleep(parseInt*1000);
	}

	public void ieCompatibilityViewSettings () throws InterruptedException, AWTException {
		try {
			Robot rob = new Robot();

			rob.keyPress(KeyEvent.VK_ALT);
			rob.keyPress(KeyEvent.VK_X);
			rob.keyRelease(KeyEvent.VK_X);
			rob.keyRelease(KeyEvent.VK_ALT);

			for (int i = 1; i <= 9; i++) {
				rob.keyPress(KeyEvent.VK_DOWN);
				rob.keyRelease(KeyEvent.VK_DOWN);
			}

			rob.keyPress(KeyEvent.VK_ENTER);
			rob.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			rob.keyPress(KeyEvent.VK_TAB);
			rob.keyRelease(KeyEvent.VK_TAB);
			Thread.sleep(1000);
			rob.keyPress(KeyEvent.VK_ENTER);
			rob.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			rob.keyPress(KeyEvent.VK_ESCAPE);
			rob.keyRelease(KeyEvent.VK_ESCAPE);
		}catch(Exception ex){}

	}
}
package dd.automation.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverHandler {
	
	// Driver Name
	private String driverName;
	
	// Constructor
	public DriverHandler(String driverName)
	{
		this.driverName = driverName;
	}

	public DriverHandler() {
	}

	// Get the driver
	public WebDriver getDriverHandler(){
		
		WebDriver driver = null;
		String path = "C:\\Temp\\JavaCABuild\\Drivers";
		
		//Select the driver by driverName
		switch(driverName){
			
			case "Chrome":
			path = path + "\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", path);
		
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			options.addArguments("disable-extensions");
			driver = new ChromeDriver(options);
			break;
		
		case "Firefox":
			path = path + "\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", path);
			driver = new FirefoxDriver();
			break;
			
		
		case "Edge":
			path = path + "\\MicrosoftWebDriver.exe";
			System.setProperty("webdriver.edge.driver", path);
			driver = new EdgeDriver();
			break;

		case "IE":
			path = path + "\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", path);
			//Initialize InternetExplorerDriver Instance.
			driver = new InternetExplorerDriver();
			break;

		default:
			System.out.println("No driver found.");
			break;
			
		}
		return driver;
	}

	public void quit(WebDriver driver) {
		driver.quit();
	}
}

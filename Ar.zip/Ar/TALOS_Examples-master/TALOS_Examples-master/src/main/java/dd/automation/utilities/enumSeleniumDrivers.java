package dd.automation.utilities;

public enum enumSeleniumDrivers {
    Chrome, IE;
}

package com.InsurancePlanes.Base;

import com.InsurancePlanes.Util.Testutil;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class TestBase {

    public  static WebDriver driver ;
    public static Properties prop;

    public TestBase(){
        try {
            prop = new Properties();
            FileInputStream ip = new FileInputStream("C:/Users/ismaile/IdeaProjects/TFSINSURANCE/src/main/java/com/InsurancePlanes/Config/config.properties");
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void initialization(){
        String BrowserName = prop.getProperty("browser");

        if(BrowserName.equals("chrome")) {

            ChromeOptions options = new ChromeOptions();
            options.setExperimentalOption("useAutomationExtension", false);
            //WebDriver driver = new ChromeDriver(options);
            String exePath = "C:\\Users\\ismaile\\Depencies\\Drivers\\chromedriver.exe";
            System.setProperty("webdriver.chrome.driver", exePath);

            //"C:\Users\ismaile\Depencies\Drivers\chromedriver.exe"
             driver = new ChromeDriver(options);

            driver.manage().window().maximize();
            driver.manage().timeouts().pageLoadTimeout(Testutil.Page_Load_Time, TimeUnit.SECONDS);
            driver.manage().deleteAllCookies();
            driver.manage().timeouts().implicitlyWait(Testutil.Implicit_Wait, TimeUnit.SECONDS);
            WebDriverWait wait = new WebDriverWait(driver,50);

            driver.get(prop.getProperty("url"));

        }

    }
}

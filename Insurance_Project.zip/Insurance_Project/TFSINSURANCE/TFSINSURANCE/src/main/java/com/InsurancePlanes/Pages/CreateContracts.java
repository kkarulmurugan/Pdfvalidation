package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;

import java.util.ArrayList;
import java.util.List;

public class CreateContracts extends TestBase {

    String [] PlanTypes;

    public CreateContracts() {
        PageFactory.initElements(driver, this);
    }


    public void programs() {
        //programs
        List<WebElement> PlanTypes1 = driver.findElements(By.xpath("//table[@class = 'quickRaterResults ui-jqgrid-btable ui-common-table']//tr"));
        PlanTypes = new String[PlanTypes1.size()];
        for(int i =0; i < PlanTypes1.size();i++){
            PlanTypes[i] = PlanTypes1.get(i).getText();
        }
    }

    @FindBy(xpath = "//*[@id='13']/td[2]")
    WebElement OpenPPM;
    @FindBy(xpath = "//tr[@id = '650']/td[1]")
    WebElement term1;
    @FindBy(xpath = "//h3[. = 'Form']")
    WebElement Form;
    //Customer fill form
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.FirstName']")
    WebElement customerFirstName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.LastName']")
    WebElement customerLastName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BusinessName']")
    WebElement CustomerBusinessName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.AddressLine1']")
    WebElement CustomerAddress1;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.AddressLine2']")
    WebElement CustomerAddress2;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.ZipCode']")
    WebElement CustomerZip;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.Phone']")
    WebElement CustomerPhone;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.FirstName']")
    WebElement CoBuyerFirstName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.LastName']")
    WebElement CoBuyerLastName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.AddressLine1']")
    WebElement CoBuyerAddressLine1;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.AddressLine2']")
    WebElement CoBuyerAddressLine2;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.ZipCode']")
    WebElement CoBuyerZip;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.Phone']")
    WebElement CoBuyerPhone;
    @FindBy(xpath = "//*[@name = 'ContractRequest.LienHolder.Name']")
    WebElement LienHolderName;
    @FindBy(xpath = "//button[.='Enter Contract and Finalize']")
    WebElement EntercontractAndFinalize;
    @FindBy(xpath = "//*[.='Duplicate Contract']")
    WebElement dublicatecontract;
    @FindBy(xpath = "//*[.='Force']")
    WebElement Force;
    @FindBy(xpath = "//*[.='Sell Another Contract to Same Customer']")
    WebElement SellAnotherContracttoSameCustomer;
    @FindBy(xpath = "//td[contains(text(),'2 YRS/ 3 SERVICES')]")
    WebElement term2;
    @FindBy(xpath = "//div[contains(@id,'lienDropDown')]/div[1]/div[2]")
    WebElement MFS;
    @FindBy(xpath = "//input[contains(@name,'deductibleInput_')]")
    WebElement deductibleInput;
    @FindBy(xpath = "//*[.='Sell Contract for New Customer']")
    WebElement SellContractforNewCustomer;



    public void getPPM() {

        for (String plans : PlanTypes) {
            System.out.println("ppm: " + plans);

            if (plans.equalsIgnoreCase("PPM Auto Care Auto Care PPM")) {
                OpenPPM.click();
                term1.click();
                Form.click();
            }
            System.out.println("ppm: " + plans);
        }
    }

    public void getCustomerFirstName(String CustomerFirstName) {
        customerFirstName.sendKeys(CustomerFirstName);
    }

    public void getcustomerLastName(String CustomerLastName) {
        customerLastName.sendKeys(CustomerLastName);
    }

    public void getCustomerBusinessName(String customerBusinessName) {
        CustomerBusinessName.sendKeys(customerBusinessName);
    }

    public void getCustomerAddress1(String customerAddress1) {
        CustomerAddress1.sendKeys(customerAddress1);
    }

    public void getCustomerAddress2(String customerAddress2) {
        CustomerAddress2.sendKeys(customerAddress2);
    }

    public void getCustomerZip(String customerZip) {
        CustomerZip.sendKeys(customerZip);
    }

    public void getCustomerPhone(String customerPhone) {
        CustomerPhone.sendKeys(customerPhone);
    }

    public void getCoBuyerFirstName(String coBuyerFirstName) {
        CoBuyerFirstName.sendKeys(coBuyerFirstName);
    }

    public void getCoBuyerLastName(String coBuyerLastName) {
        CoBuyerLastName.sendKeys(coBuyerLastName);
    }

    public void getCoBuyerAddressLine1(String coBuyerAddressLine1) {
        CoBuyerAddressLine1.sendKeys(coBuyerAddressLine1);
    }

    public void getCoBuyerAddressLine2(String coBuyerAddressLine2) {
        CoBuyerAddressLine2.sendKeys(coBuyerAddressLine2);
    }

    public void getCoBuyerZip(String coBuyerZip) {
        CoBuyerZip.sendKeys(coBuyerZip);
    }

    public void getCoBuyerPhone(String coBuyerPhone) {
        CoBuyerPhone.sendKeys(coBuyerPhone);
    }

    public void getLienHolderName(String lienHolderName) {
        LienHolderName.sendKeys(lienHolderName);
    }

    public void getMFS() {
        MFS.click();
    }

    public void getEntercontractAndFinalize() {
        EntercontractAndFinalize.click();
    }

    public void getdublicatecontract() {
        String dublicateContract = dublicatecontract.getText();
        if (dublicateContract.equalsIgnoreCase("Duplicate Contract")) {
            Force.click();
        }
    }


    //give 3 seconds wait time
    public void getSellAnotherContracttoSameCustomer() {
        SellAnotherContracttoSameCustomer.click();
    }

    public void getterm2() {
        SellAnotherContracttoSameCustomer.click();
        term2.click();
        EntercontractAndFinalize.click();
        getdublicatecontract();
    }

    public void getVSC() {
        for (String plans : PlanTypes) {

            System.out.println( "vsc: "+ plans );

            if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar WA) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='149']")).click();
                driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='71']")).click();
                driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153' ]/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                driver.findElement(By.xpath("//tr[@id = 'VSC New POS Platinum VSA (TMIS 1st Dollar) VSA' ]/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar WA) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='148']/td[2]")).click();
                driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Surety CLP) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='130' or @id = 'clp']")).click();
                driver.findElement(By.xpath("//*[@id='VSC New Window Platinum VSA (TMIS Surety CLP) VSA']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='79' or @id = 'clp']")).click();
                driver.findElement(By.xpath("//tr[@id = 'VSC New Window Platinum VSA (TMIS 1st Dollar) VSA']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='70']")).click();
                driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='126']")).click();
                driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='5']")).click();
                driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='66']")).click();
                driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Surety CLP) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='pos']")).click();
                driver.findElement(By.xpath("//*[@id='904']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='127']")).click();
                driver.findElement(By.xpath("//*[@id='1202']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC Used Gold VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='145']")).click();
                driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC Used Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='72']")).click();
                driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    public void getGAP() throws InterruptedException {
        for (String plans : PlanTypes) {
            System.out.println("GAP: " + plans);
            if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='149']")).click();
                driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='71']")).click();
                driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail New GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                System.out.println("here9");
                driver.findElement(By.xpath("//*[@id='80' or @id = '118']")).click();
                driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '69' or @id = '67']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='148']/td[2]")).click();
                driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='130' or @id = 'clp']")).click();
                driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease New GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='79' or @id = 'clp']")).click();
                driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[1]"));
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease Used GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='70']")).click();
                driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail Used GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='126']")).click();
                driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='5']")).click();
                driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail New GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='66']")).click();
                driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease New GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='pos']")).click();
                driver.findElement(By.xpath("//*[@id='904']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    public void getANC() {
        for (String plans : PlanTypes) {
            System.out.println("ANC: " + plans);
            if (plans.equalsIgnoreCase("ANC New Lease EWU (TMIC Other Liability) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='149']")).click();
                driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC New Lease EWU (TMIS Non-Insured) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='71']")).click();
                driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC Certified Lease EWU (TMIC Other Liability) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC Certified Lease EWU (TMIS Non-Insured) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='148']/td[2]")).click();
                driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")).click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    public void getSellContractforNewCustomer() {
        SellContractforNewCustomer.click();
    }
}

package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.util.List;

public class ExtractData extends TestBase {


    public static void dataExtraction() throws Exception {

        String excelFilePath = "C:\\TalosData\\MazdaNew.xlsx";
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheetAt(1);
        int lastRow = sheet.getLastRowNum();
        Row row = sheet.createRow(++lastRow);

        WebElement VINNum = driver.findElement(By.cssSelector("input[name = 'VIN']"));
        row.createCell(2).setCellValue(     VINNum.getAttribute("value")     );
                WebElement Odometer = driver.findElement(By.cssSelector("input[name = 'ModelObject.Odometer']"));
        row.createCell(3).setCellValue(Odometer.getAttribute("value"));
        System.out.println(Odometer.getAttribute("value"));
        WebElement PurchaseType = driver.findElement(By.cssSelector("input[name = 'ModelObject.PurchaseType']"));
        row.createCell(4).setCellValue(PurchaseType.getAttribute("value"));
        WebElement PurchaseDate = driver.findElement(By.cssSelector("input[name = 'ModelObject.VehiclePurchaseDate']"));
        row.createCell(5).setCellValue(PurchaseDate.getAttribute("value"));
        WebElement FinanceAmount = driver.findElement(By.cssSelector("input[name = 'ModelObject.FinanceAmount']"));
        row.createCell(8).setCellValue(FinanceAmount.getAttribute("value"));
        WebElement FinanceLength = driver.findElement(By.cssSelector("input[name = 'ModelObject.FinanceLength']"));
        row.createCell(9).setCellValue(FinanceLength.getAttribute("value"));
        WebElement FinanceType = driver.findElement(By.xpath("//div[@name= 'ModelObject.FinanceType']/input[2]"));
        row.createCell(10).setCellValue(FinanceType.getAttribute("value"));
        WebElement MSRP = driver.findElement(By.cssSelector("input[name = 'ModelObject.MSRP']"));
        row.createCell(11).setCellValue(MSRP.getAttribute("value"));
        WebElement Dealer = driver.findElement(By.xpath("//input[contains(@name, 'dealerDropDown_')]"));
        row.createCell(12).setCellValue(Dealer.getAttribute("value"));
//        WebElement Mazda = driver.findElement(By.xpath("//span[contains(text(), 'MAZDA')]"));
//        row.createCell(1).setCellValue(Mazda.getAttribute("value"));


        //programs
        List<WebElement> PlanTypes = driver.findElements(By.xpath("//table[@class = 'quickRaterResults ui-jqgrid-btable ui-common-table']//tr"));
        int planTypesCount = PlanTypes.size();
        System.out.println("There are " + (planTypesCount - 1) + " plan types available:");

        System.out.println("------------------plan Types----------------------------");
        for (int i = 0; i < planTypesCount; i++) {

            System.out.println(PlanTypes.get(i).getText());

            System.out.println();
        }


        for (int i = 0; i < planTypesCount; i++) {

            if (PlanTypes.get(i).getText().equalsIgnoreCase("PPM Auto Care Auto Care PPM")) {

                driver.findElement(By.xpath("//*[@id='13']/td[2]")).click();
                WebElement PPMType = driver.findElement(By.xpath("//td[contains(text(),'PPM')][1]"));
                row.createCell(14).setCellValue(PPMType.getText());

                WebElement PPMPlan = driver.findElement(By.xpath("//td[contains(text(),'Auto Care')][1]"));
                row.createCell(15).setCellValue(PPMPlan.getText());

                WebElement PPMProduct = driver.findElement(By.xpath("//td[contains(text(),'Auto Care')][2]"));
                row.createCell(16).setCellValue(PPMProduct.getText());

                WebElement PPMPogram = driver.findElement(By.xpath("//td[contains(text(),'PPM')][2]"));
                row.createCell(17).setCellValue(PPMPogram.getText());

                WebElement PPMterm1 = driver.findElement(By.xpath("//tr[@id = '650']/td[1]"));
                row.createCell(18).setCellValue(PPMterm1.getText());

                WebElement PPMLimit1 = driver.findElement(By.xpath("//tr[@id = '650']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit1.getText());

                WebElement PPMClassCode = driver.findElement(By.xpath("//tr[@id = '650']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode.getText());

                WebElement PPMRateId = driver.findElement(By.xpath("//tr[@id = '650']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId.getText());

                WebElement PPMSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '650']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm2 = driver.findElement(By.xpath("//td[contains(text(),'1 YR/ 3 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm2.getText());

                WebElement PPMLimit2 = driver.findElement(By.xpath("//tr[@id = '651']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit2.getText());

                WebElement PPMClassCode2 = driver.findElement(By.xpath("//tr[@id = '651']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode2.getText());

                WebElement PPMRateId2 = driver.findElement(By.xpath("//tr[@id = '651']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId2.getText());

                WebElement PPMSuggestedRetailPrice2 = driver.findElement(By.xpath("//tr[@id = '651']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice2.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm3 = driver.findElement(By.xpath("//td[contains(text(),'2 YRS/ 3 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm3.getText());

                WebElement PPMLimit3 = driver.findElement(By.xpath("//tr[@id = '652']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit3.getText());

                WebElement PPMClassCode3 = driver.findElement(By.xpath("//tr[@id = '652']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode3.getText());

                WebElement PPMRateId3 = driver.findElement(By.xpath("//tr[@id = '652']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId3.getText());

                WebElement PPMSuggestedRetailPrice3 = driver.findElement(By.xpath("//tr[@id = '652']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice3.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm4 = driver.findElement(By.xpath("//td[contains(text(),'2 YRS/ 5 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm4.getText());

                WebElement PPMLimit4 = driver.findElement(By.xpath("//tr[@id = '653']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit4.getText());

                WebElement PPMClassCode4 = driver.findElement(By.xpath("//tr[@id = '653']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode4.getText());

                WebElement PPMRateId4 = driver.findElement(By.xpath("//tr[@id = '653']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId4.getText());

                WebElement PPMSuggestedRetailPrice4 = driver.findElement(By.xpath("//tr[@id = '653']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice4.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm5 = driver.findElement(By.xpath("//td[contains(text(),'3 YRS/ 5 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm5.getText());

                WebElement PPMLimit5 = driver.findElement(By.xpath("//tr[@id = '654']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit5.getText());

                WebElement PPMClassCode5 = driver.findElement(By.xpath("//tr[@id = '654']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode5.getText());

                WebElement PPMRateId5 = driver.findElement(By.xpath("//tr[@id = '654']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId5.getText());

                WebElement PPMSuggestedRetailPrice5 = driver.findElement(By.xpath("//tr[@id = '654']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice5.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm6 = driver.findElement(By.xpath(" //td[contains(text(),'3 YRS/ 8 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm6.getText());

                WebElement PPMLimit6 = driver.findElement(By.xpath("//tr[@id = '655']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit6.getText());

                WebElement PPMClassCode6 = driver.findElement(By.xpath("//tr[@id = '655']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode6.getText());

                WebElement PPMRateId6 = driver.findElement(By.xpath("//tr[@id = '655']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId6.getText());

                WebElement PPMSuggestedRetailPrice6 = driver.findElement(By.xpath("//tr[@id = '655']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice6.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm7 = driver.findElement(By.xpath(" //td[contains(text(),'4 YRS/ 11 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm7.getText());

                WebElement PPMLimit7 = driver.findElement(By.xpath("//tr[@id = '656']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit7.getText());

                WebElement PPMClassCode7 = driver.findElement(By.xpath("//tr[@id = '656']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode7.getText());

                WebElement PPMRateId7 = driver.findElement(By.xpath("//tr[@id = '656']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId7.getText());

                WebElement PPMSuggestedRetailPrice7 = driver.findElement(By.xpath("//tr[@id = '656']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice7.getText());


                row = sheet.createRow(++lastRow);
                WebElement PPMterm8 = driver.findElement(By.xpath("//td[contains(text(),'4 YRS/ 7 SERVICES')]"));
                row.createCell(18).setCellValue(PPMterm8.getText());

                WebElement PPMLimit8 = driver.findElement(By.xpath("//tr[@id = '657']/td[2]"));
                row.createCell(19).setCellValue(PPMLimit8.getText());

                WebElement PPMClassCode8 = driver.findElement(By.xpath("//tr[@id = '657']/td[3]"));
                row.createCell(20).setCellValue(PPMClassCode8.getText());

                WebElement PPMRateId8 = driver.findElement(By.xpath("//tr[@id = '657']/td[4]"));
                row.createCell(21).setCellValue(PPMRateId8.getText());

                WebElement PPMSuggestedRetailPrice8 = driver.findElement(By.xpath("//tr[@id = '657']/td[5]"));
                row.createCell(24).setCellValue(PPMSuggestedRetailPrice8.getText());

                System.out.println();
                driver.findElement(By.xpath("//*[@id='13']/td[2]")).click();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar WA) VSA")) {

                driver.findElement(By.xpath("//*[@id='149']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWAType = driver.findElement(By.xpath("//*[@id='149']/td[2]"));
                row.createCell(14).setCellValue(VSCWAType.getText());

                WebElement VSCWAPlan = driver.findElement(By.xpath(" //*[@id='149']/td[3]"));
                row.createCell(15).setCellValue(VSCWAPlan.getText());

                WebElement VSCWAProduct = driver.findElement(By.xpath("//*[@id='149']/td[4]"));
                row.createCell(16).setCellValue(VSCWAProduct.getText());

                WebElement VSCWAPogram = driver.findElement(By.xpath("//*[@id='149']/td[5]"));
                row.createCell(17).setCellValue(VSCWAPogram.getText());

                WebElement VSCWAterm1 = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]"));
                row.createCell(18).setCellValue(VSCWAterm1.getText());

                WebElement VSCWALimit1 = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[2]"));
                row.createCell(19).setCellValue(VSCWALimit1.getText());

                WebElement VSCWAClassCode = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[3]"));
                row.createCell(20).setCellValue(VSCWAClassCode.getText());

                WebElement VSCWARateId = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[4]"));
                row.createCell(21).setCellValue(VSCWARateId.getText());

                WebElement VSCWASuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[5]"));
                row.createCell(24).setCellValue(VSCWASuggestedRetailPrice.getText());

                row = sheet.createRow(++lastRow);
                WebElement VSCWAterm2 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[1]"));
                row.createCell(18).setCellValue(VSCWAterm2.getText());

                WebElement VSCWALimit2 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[2]"));
                row.createCell(19).setCellValue(VSCWALimit2.getText());

                WebElement VSCWAClassCode1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[3]"));
                row.createCell(20).setCellValue(VSCWAClassCode1.getText());

                WebElement VSCWARateId1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[4]"));
                row.createCell(21).setCellValue(VSCWARateId1.getText());

                WebElement VSCWASuggestedRetailPrice1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[5]"));
                row.createCell(24).setCellValue(VSCWASuggestedRetailPrice1.getText());
                System.out.println();


            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Non-Insured) VSA")) {

                driver.findElement(By.xpath("//*[@id='71']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath("//td[contains(text(),'VSC')][1][position()=1]"));
                row.createCell(14).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath("//td[contains(text(),'New POS Platinum')][1][position()=1]"));
                row.createCell(15).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath("//td[contains(text(),'VSA (TMIS Non-Insured)')][1][position()=1]"));
                row.createCell(16).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath("//tr[@id = '71']/td[5]"));
                row.createCell(17).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[1]"));
                row.createCell(18).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[2]"));
                row.createCell(19).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[3]"));
                row.createCell(20).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[4]"));
                row.createCell(21).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[5]"));
                row.createCell(24).setCellValue(VSCSuggestedRetailPrice.getText());


                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[1]"));
                row.createCell(18).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[2]"));
                row.createCell(19).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[3]"));
                row.createCell(20).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[4]"));
                row.createCell(21).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[5]"));
                row.createCell(24).setCellValue(VSCSuggestedRetailPrice2.getText());
                driver.findElement(By.xpath("//*[@id='71']")).click();

                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar) VSA")) {
                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);
                row.createCell(1).setCellValue("ADD THIS PLAN");
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar WA) VSA")) {
                driver.findElement(By.xpath("//*[@id='148']/td[2]")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWAType = driver.findElement(By.xpath("//*[@id='148']/td[2]"));
                row.createCell(14).setCellValue(VSCWAType.getText());

                WebElement VSCWAPlan = driver.findElement(By.xpath("//*[@id='148']/td[3]"));
                row.createCell(15).setCellValue(VSCWAPlan.getText());

                WebElement VSCWAProduct = driver.findElement(By.xpath("//*[@id='148']/td[4]"));
                row.createCell(16).setCellValue(VSCWAProduct.getText());

                WebElement VSCWAPogram = driver.findElement(By.xpath("//*[@id='148']/td[5]"));
                row.createCell(17).setCellValue(VSCWAPogram.getText());

                WebElement VSCWAterm1 = driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]"));
                row.createCell(18).setCellValue(VSCWAterm1.getText());

                WebElement VSCWALimit1 = driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[2]"));
                row.createCell(19).setCellValue(VSCWALimit1.getText());

                WebElement VSCWAClassCode = driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[3]"));
                row.createCell(20).setCellValue(VSCWAClassCode.getText());

                WebElement VSCWARateId = driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[4]"));
                row.createCell(21).setCellValue(VSCWARateId.getText());

                WebElement VSCWASuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[5]"));
                row.createCell(24).setCellValue(VSCWASuggestedRetailPrice.getText());


                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Surety CLP) VSA")) {
                driver.findElement(By.xpath("//*[@id='130' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);
                row.createCell(1).setCellValue("ADD THIS PLAN");
                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar) VSA")) {
                driver.findElement(By.xpath("//*[@id='79' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);
                row.createCell(1).setCellValue("ADD THIS PLAN");
                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Non-Insured) VSA")) {
                driver.findElement(By.xpath("//*[@id='70']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCWType = driver.findElement(By.xpath("//tr[@id = '70']/td[2]"));
                row.createCell(14).setCellValue(VSCWType.getText());

                WebElement VSCWPlan = driver.findElement(By.xpath("//tr[@id = '70']/td[3]"));
                row.createCell(15).setCellValue(VSCWPlan.getText());

                WebElement VSCWProduct = driver.findElement(By.xpath("//tr[@id = '70']/td[4]"));
                row.createCell(16).setCellValue(VSCWProduct.getText());

                WebElement VSCWPogram = driver.findElement(By.xpath("//tr[@id = '70']/td[5]"));
                row.createCell(17).setCellValue(VSCWPogram.getText());

                WebElement VSCWterm1 = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]"));
                row.createCell(18).setCellValue(VSCWterm1.getText());

                WebElement VSCWLimit1 = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[2]"));
                row.createCell(19).setCellValue(VSCWLimit1.getText());

                WebElement VSCWClassCode = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[3]"));
                row.createCell(20).setCellValue(VSCWClassCode.getText());

                WebElement VSCWRateId = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[4]"));
                row.createCell(21).setCellValue(VSCWRateId.getText());

                WebElement VSCWSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[5]"));
                row.createCell(24).setCellValue(VSCWSuggestedRetailPrice.getText());
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New POS Platinum VSA (TMIC Insured FL) VSA")) {
                driver.findElement(By.xpath("//*[@id='126']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCFLType = driver.findElement(By.xpath("//*[@id='126']/td[2]"));
                row.createCell(14).setCellValue(VSCFLType.getText());

                WebElement CSVFLPlan = driver.findElement(By.xpath("//*[@id='126']/td[3]"));
                row.createCell(15).setCellValue(CSVFLPlan.getText());

                WebElement CVSFLProduct = driver.findElement(By.xpath("//*[@id='126']/td[4]"));
                row.createCell(16).setCellValue(CVSFLProduct.getText());

                WebElement CSVFLPogram = driver.findElement(By.xpath("//*[@id='126']/td[5]"));
                row.createCell(17).setCellValue(CSVFLPogram.getText());

                WebElement CSVFLterm1 = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[1]"));
                row.createCell(18).setCellValue(CSVFLterm1.getText());

                WebElement CSVFLLimit1 = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[2]"));
                row.createCell(19).setCellValue(CSVFLLimit1.getText());

                WebElement CSVFLClassCode = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[3]"));
                row.createCell(20).setCellValue(CSVFLClassCode.getText());

                WebElement CSVFLRateId = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[4]"));
                row.createCell(21).setCellValue(CSVFLRateId.getText());

                WebElement CSVFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[5]"));
                row.createCell(24).setCellValue(CSVFLSuggestedRetailPrice.getText());


                row = sheet.createRow(++lastRow);
                WebElement CSVFLterm2 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[1]"));
                row.createCell(18).setCellValue(CSVFLterm2.getText());

                WebElement CSVFLLimit2 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[2]"));
                row.createCell(19).setCellValue(CSVFLLimit2.getText());

                WebElement CSVFLClassCode1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[3]"));
                row.createCell(20).setCellValue(CSVFLClassCode1.getText());

                WebElement CSVFLRateId1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[4]"));
                row.createCell(21).setCellValue(CSVFLRateId1.getText());

                WebElement CSVFLSuggestedRetailPrice1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[5]"));
                row.createCell(24).setCellValue(CSVFLSuggestedRetailPrice1.getText());

                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Window Platinum VSA (TMIC Insured FL) VSA")) {
                driver.findElement(By.xpath("//*[@id='5']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='5']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='5']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='5']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='5']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Platinum VSA (TMIS Non-Insured) VSA")) {
                driver.findElement(By.xpath("//*[@id='66']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='66']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='66']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='66']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='66']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Surety CLP) VSA")) {
                driver.findElement(By.xpath("//*[@id='pos']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='66']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='66']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='66']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='66']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='904']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='904']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='904']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='904']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='904']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC New Platinum VSA (TMIC Insured FL) VSA")) {
                driver.findElement(By.xpath("//*[@id='127']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='127']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='127']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='127']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='127']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='1202']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='1202']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='1202']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='1202']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1202']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();

                row = sheet.createRow(++lastRow);
                WebElement CSVWFLterm2 = driver.findElement(By.xpath("//*[@id='962']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm2.getText());

                WebElement CSVWFLLimit2 = driver.findElement(By.xpath("//*[@id='962']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit2.getText());

                WebElement CSVWFLClassCode2 = driver.findElement(By.xpath("//*[@id='962']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode2.getText());

                WebElement CSVWFLRateId2 = driver.findElement(By.xpath("//*[@id='962']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId2.getText());

                WebElement CSVWFLSuggestedRetailPrice2 = driver.findElement(By.xpath("//*[@id='962']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice2.getText());
                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC Used Gold VSA (TMIS Non-Insured) VSA")) {
                driver.findElement(By.xpath("//*[@id='145']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='145']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='145']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='145']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='145']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("VSC Used Platinum VSA (TMIS Non-Insured) VSA")) {
                driver.findElement(By.xpath("//*[@id='72']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='72']/td[2]"));
                row.createCell(14).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='72']/td[3]"));
                row.createCell(15).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='72']/td[4]"));
                row.createCell(16).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='72']/td[5]"));
                row.createCell(17).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[1]"));
                row.createCell(18).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[2]"));
                row.createCell(19).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[3]"));
                row.createCell(20).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[4]"));
                row.createCell(21).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[5]"));
                row.createCell(24).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Balloon GAP (TMIC Other Liability) GAP")) {
                driver.findElement(By.xpath("//*[@id='135' or @id = '120']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPType = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[2]"));
                row.createCell(14).setCellValue(GAPType.getText());

                WebElement GAPPlan = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[3]"));
                row.createCell(15).setCellValue(GAPPlan.getText());

                WebElement GAPProduct = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[4]"));
                row.createCell(16).setCellValue(GAPProduct.getText());

                WebElement GAPPogram = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[5]"));
                row.createCell(17).setCellValue(GAPPogram.getText());

                WebElement GAPterm1 = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[1]"));
                row.createCell(18).setCellValue(GAPterm1.getText());

                WebElement GAPLimit1 = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[2]"));
                row.createCell(19).setCellValue(GAPLimit1.getText());

                WebElement GAPClassCode = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[3]"));
                row.createCell(20).setCellValue(GAPClassCode.getText());

                WebElement GAPRateId = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[4]"));
                row.createCell(21).setCellValue(GAPRateId.getText());

                WebElement GAPSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[5]"));
                row.createCell(24).setCellValue(GAPSuggestedRetailPrice.getText());

                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Balloon GAP (TMIC Credit LIne - NY) GAP")) {
                driver.findElement(By.xpath("//*[@id='133']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPType = driver.findElement(By.xpath("//tr[@id = '133']/td[2]"));
                row.createCell(14).setCellValue(GAPType.getText());

                WebElement GAPPlan = driver.findElement(By.xpath("//tr[@id = '133']/td[3]"));
                row.createCell(15).setCellValue(GAPPlan.getText());

                WebElement GAPProduct = driver.findElement(By.xpath("//tr[@id = '133']/td[4]"));
                row.createCell(16).setCellValue(GAPProduct.getText());

                WebElement GAPPogram = driver.findElement(By.xpath("//tr[@id = '133']/td[5]"));
                row.createCell(17).setCellValue(GAPPogram.getText());

                WebElement GAPterm1 = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[1]"));
                row.createCell(18).setCellValue(GAPterm1.getText());

                WebElement GAPLimit1 = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[2]"));
                row.createCell(19).setCellValue(GAPLimit1.getText());

                WebElement GAPClassCode = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[3]"));
                row.createCell(20).setCellValue(GAPClassCode.getText());

                WebElement GAPRateId = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[4]"));
                row.createCell(21).setCellValue(GAPRateId.getText());

                WebElement GAPSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[5]"));
                row.createCell(24).setCellValue(GAPSuggestedRetailPrice.getText());

                System.out.println();

            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Retail New GAP (TMIC Other Liability) GAP")) {
                driver.findElement(By.xpath("//*[@id='118']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='118' or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();

            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Lease New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '134']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='134']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='134']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='134']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='134']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Retail New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '135']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Lease New GAP (TMIC Other Liability) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Lease Used GAP (TMIC Other Liability) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116' or @id = '117']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Retail Used GAP (TMIC Other Liability) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116' or @id = '119']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Balloon GAP (TMIC Misc Casualty) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '115']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='115']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='115']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='115']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='115']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            } else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Retail New GAP (TMIC Misc Casualty) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '113']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='113']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='113']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='113']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='113']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '55']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '55']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '55']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '55']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '55']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("GAP Lease New GAP (TMIC Misc Casualty) GAP")) {
                driver.findElement(By.xpath("//tr[@id = '111']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='111']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='111']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='111']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='111']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '37']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '37']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '37']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '37']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '37']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("ANC New Lease EWU (TMIC Other Liability) EWU")) {
                driver.findElement(By.xpath("//*[@id='16']")).click();
                row = sheet.createRow(++lastRow);

                WebElement ANCType = driver.findElement(By.xpath("//tr[@id = '16']/td[2]"));
                row.createCell(14).setCellValue(ANCType.getText());

                WebElement ANCPlan = driver.findElement(By.xpath("//tr[@id = '16']/td[3]"));
                row.createCell(15).setCellValue(ANCPlan.getText());

                WebElement ANCProduct = driver.findElement(By.xpath("//tr[@id = '16']/td[4]"));
                row.createCell(16).setCellValue(ANCProduct.getText());

                WebElement ANCPogram = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(17).setCellValue(ANCPogram.getText());

                WebElement ANCterm1 = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(18).setCellValue(ANCterm1.getText());

                WebElement ANCLimit1 = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(19).setCellValue(ANCLimit1.getText());

                WebElement ANCClassCode = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(20).setCellValue(ANCClassCode.getText());

                WebElement ANCRateId = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(21).setCellValue(ANCRateId.getText());

                WebElement ANCSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(24).setCellValue(ANCSuggestedRetailPrice.getText());
                System.out.println();

            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("ANC New Lease EWU (TMIS Non-Insured) EWU")) {
                driver.findElement(By.xpath("//*[@id='6']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='6']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='6']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='6']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='6']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("ANC Certified Lease EWU (TMIC Other Liability) EWU")) {
                driver.findElement(By.xpath("//*[@id='19']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='19']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='19']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='19']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='19']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else if (PlanTypes.get(i).getText().equalsIgnoreCase("ANC Certified Lease EWU (TMIS Non-Insured) EWU")) {
                driver.findElement(By.xpath("//*[@id='7']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='7']/td[2]"));
                row.createCell(14).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='7']/td[3]"));
                row.createCell(15).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='7']/td[4]"));
                row.createCell(16).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='7']/td[5]"));
                row.createCell(17).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '405']/td[1]"));
                row.createCell(18).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '405']/td[2]"));
                row.createCell(19).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '405']/td[3]"));
                row.createCell(20).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '405']/td[4]"));
                row.createCell(21).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '405']/td[5]"));
                row.createCell(24).setCellValue(GAPRSuggestedRetailPrice.getText());

                System.out.println();
            }else {

                row = sheet.createRow(++lastRow);
                System.out.println(PlanTypes.get(i).getText());
                row.createCell(1).setCellValue(PlanTypes.get(i).getText());

                System.out.println("Add " + PlanTypes.get(i).getText());
            }


        }

        inputStream.close();
        FileOutputStream outFile = new FileOutputStream(new File("C:\\TalosData\\MazdaNew.xlsx"));

        workbook.write(outFile);
        outFile.close();
        System.out.println(" is successfully written");
    }
}
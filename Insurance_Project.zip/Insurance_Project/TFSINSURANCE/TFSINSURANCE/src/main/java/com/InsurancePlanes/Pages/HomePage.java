package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Testdata.ReadExcel;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class HomePage extends TestBase {

    @FindBy(css = "#Contracts-QuickRater")
    WebElement QuickRater;

    @FindBy(xpath = "//input[@name = 'VIN']")
    WebElement VinNumber;

    @FindBy(xpath = "//input[@name = 'ModelObject.Odometer']")
    WebElement Odometer;

    @FindBy(xpath = "//label[text()[. = 'Purchase Type']]/..//span[contains(@class, 'icon-triangle')]")
    WebElement purchaseType;

    @FindBy(xpath = "//div[text()[. = 'New']]")
    WebElement purchaseTypeSelect;

    @FindBy(xpath = "//input[@name = 'ModelObject.VehiclePurchaseDate']")
    WebElement purchaseDate;

    @FindBy(xpath = "//input[@name = 'ModelObject.PurchasePrice']")
    WebElement PurchasePrice;

    @FindBy(xpath = "//input[@name = 'ModelObject.InserviceDate']")
    WebElement InServiceDate;

    @FindBy(xpath = "//input[@name = 'ModelObject.FinanceAmount']")
    WebElement FinanceAmount;

    @FindBy(xpath = "//input[@name = 'ModelObject.FinanceLength']")
    WebElement FinanceLength;

    @FindBy(xpath = "//div[@name = 'ModelObject.FinanceType']/span")
    WebElement FinanceType;

    @FindBy(xpath = "//div[@name = 'ModelObject.FinanceType']")
    WebElement FinanceTypeSelect;

    @FindBy(xpath = "//input[@name = 'ModelObject.MSRP']")
    WebElement MSRP;

    @FindBy(xpath = "//div[@name = 'DealerId']/span[1]/span")
    WebElement SelectDealerDropDown;

    @FindBy(xpath = "//div[@name = 'DealerId']/input[2]")
    WebElement SelectDealer;

    @FindBy(xpath = "//div[@class = 'ui-widget-content ui-corner-bottom']/div[1]/div[2]")
    WebElement SelectDealerLeft;


    @FindBy(xpath = "//button[text()[. = 'Get Rates']]")
    WebElement GetRates;

    @FindBy(xpath = "")
    WebElement plansTable;

    @FindBy(xpath = "//div[@class = 'ui-jqgrid-bdiv']/div/table/tbody")
    WebElement ProgramsTable;

    @FindBy(xpath = "//div[@class = 'ui-jqgrid-bdiv']/div/table/tbody/tr[2]/td/a/span")
    WebElement PPM;

    @FindBy(xpath = "//tr[@class = 'ui-subgrid ui-sg-expanded']/td[2]/div/div/div[3]/div[3]/div/table/tbody")
    WebElement PlansTable;

    @FindBy(xpath = "//tr[@class = 'ui-subgrid ui-sg-expanded']/td[2]/div/div/div[3]/div[3]/div/table/tbody/tr[2]")
    WebElement plan1;

    @FindBy(xpath = "//h3[@class= 'ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']")
    WebElement Form;
    @FindBy(name = "ContractRequest.Customer.FirstName")
    WebElement CustomerFirstName;
    @FindBy(name = "ContractRequest.Customer.LastName")
    WebElement CustomerLastName;
    @FindBy(name = "ContractRequest.Customer.EmailAddress")
    WebElement CustomerEmail;
    @FindBy(name = "ContractRequest.Customer.BillingAddress.AddressLine1")
    WebElement CustomerAddress;
    @FindBy(name = "ContractRequest.Customer.BillingAddress.ZipCode")
    WebElement CustomerZipCode;

    @FindBy(xpath = "//button[contains(text(),'View Draft Documents')]")
    WebElement ViewDraftDocument;
    @FindBy(xpath = "//span[@class= 'ui-button-icon ui-icon ui-icon-closethick']")
    WebElement CloseViewDraftDocument;

    @FindBy(xpath = "//button[text()[. = 'Enter Contract and Finalize']]")
    WebElement EnterContractandFinalize;

    @FindBy(xpath = "//button[text()[. = 'Print Available Documents']]")
    WebElement Success_PrintAvailableDocs;
    @FindBy(xpath = "//div[contains(@class, 'draggable')][2]//button[@title='Close']")
    WebElement Success_ClosePrintAvailableDocs;

    @FindBy(xpath = "//button[contains(text(), 'Sell Another Contract to Same Customer')]")
    WebElement Success_SellAnotherContractToSameCustomer;
    @FindBy(xpath = "//tr[@id = '651']/td[2]")
    WebElement Success_SellAnotherContractToSameCustomer_Selectplan;
    @FindBy(xpath = "")
    WebElement Success_SellAnotherContractToSameCustomer_Form;
    @FindBy(xpath = "")
    WebElement Success_SellAnotherContractToSameCustomer_EnterContractAndFinalize;
    @FindBy(xpath = "//div[@class = 'ui-dialog-buttonset']/button[1]")
    WebElement ForceDublicateContract;

    @FindBy(xpath = "//h3[.='Contracts']")
    WebElement Contracts;

    //Iteration completed



    public HomePage(){
        PageFactory.initElements(driver, this);
    }

    public void clickOnQuickRater(){
        QuickRater.click();
    }

    public void VinNumber(String str)  {

        VinNumber.click();

        VinNumber.sendKeys(str);
    }

    public void getOdometer(String odo){
        Odometer.click();
        Odometer.sendKeys(odo);
    }

    public void getPurchaseType( String PurchaseT){
        purchaseType.click();
        driver.findElement(By.xpath("//div[text() = '"+PurchaseT+"']")).click();
        //purchaseTypeSelect.click();
    }

    public void getPurchaseDate(String date){
        purchaseDate.sendKeys(date);
    }

    public void getPurchasePrice(String price){
        PurchasePrice.sendKeys(price);
    }

    public void getInServiceDate(String inservicedate){
        InServiceDate.sendKeys(inservicedate);
    }

    public void getFinanceAmount(String amount){
        FinanceAmount.sendKeys(amount);
    }

    public void getFinanceLength(String length){
        FinanceLength.sendKeys(length);
    }

    public void getFinanceType(String Financet) throws InterruptedException {


        driver.findElement(By.xpath("//div[@name = 'ModelObject.FinanceType']/span/span")).click();

//      String s1 =   "//div[@class='ui-corner-all' or @class = 'ui-corner-all ui-state-active'][.='";
//      String s2 = "']";
//
//      String s1s2 = s1+Financet+s2;
      driver.findElement(By.xpath("//div[text() = '"+Financet+"']")).click();
        //FinanceTypeSelect.sendKeys(Financet);

    }

    public void getMSRP(String msrp){
        MSRP.sendKeys(msrp);
    }

    public void getDealer(String dealer) throws InterruptedException {

        SelectDealerDropDown.click();
        //emSelectDealer.click();
        SelectDealer.clear();
        Thread.sleep(2000);
        SelectDealer.sendKeys(dealer);
        Thread.sleep(2000);
        SelectDealerLeft.click();
    }

    public void getGetRates(){
        GetRates.click();
    }

    public void getPlansList(){
        int j = 0;
        System.out.println("--------------------Iteration: "+ j + "---------------------------------------");
        List<WebElement> PlansRowsList =  ProgramsTable.findElements(By.tagName("tr"));
        int NumberOfPrograms = PlansRowsList.size();
        System.out.println("There are " + (NumberOfPrograms-1) + " programs available:\n");

        j++;
        for( int i = 0 ; i < NumberOfPrograms; i++) {
            System.out.println(PlansRowsList.get(i).getText());
        }

    }

    public void getPPM(){ PPM.click();
    }

    public void getPlans(){
        List<WebElement> PlansRowsList =  PlansTable.findElements(By.tagName("tr"));
        int NumberOfPlans = PlansRowsList.size();
        System.out.println("\n");
        System.out.println("There are " + (NumberOfPlans-1) + " plans available:\n");

        for(int i = 0 ; i < NumberOfPlans; i++) {
            System.out.println(PlansRowsList.get(i).getText());
        }

        plan1.click();

        System.out.println("---------------------------------------------------------------");
    }

    public void getForm(){
        Form.click();
        CustomerFirstName.sendKeys("Kevin");
        CustomerLastName.sendKeys("Mendoza");
        CustomerEmail.sendKeys("kevin@gmail.com");
        CustomerAddress.sendKeys("1119 armond road, plano");
        CustomerZipCode.sendKeys("75024");


    }

    public void getViewDraftdoc(){
        ViewDraftDocument.click();
    }
    public void getCloseViewDraftDocument(){
        CloseViewDraftDocument.click();
    }

    public void getEnterContractandFinalize() throws Exception {
        EnterContractandFinalize.click();
        Thread.sleep(2000);
        ForceDublicateContract.click();
    }

    public void getSuccess_PrintAvailableDocs(){
        Success_PrintAvailableDocs.click();
    }

    public void getSuccess_ClosePrintAvailableDocs(){
        Success_ClosePrintAvailableDocs.click();
    }
    public void getSuccess_SellAnotherContractToSameCustomer(){
        Success_SellAnotherContractToSameCustomer.click();
    }

    public void getSuccess_SellAnotherContractToSameCustomer_Selectplan(){
        Success_SellAnotherContractToSameCustomer_Selectplan.click();
        Form.click();
    }

    public void getContracts(){
        Contracts.click();
    }
}



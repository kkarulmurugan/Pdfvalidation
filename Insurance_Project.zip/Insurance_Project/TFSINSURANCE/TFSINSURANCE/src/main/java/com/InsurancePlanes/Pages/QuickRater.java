package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;

public class QuickRater extends TestBase {
}

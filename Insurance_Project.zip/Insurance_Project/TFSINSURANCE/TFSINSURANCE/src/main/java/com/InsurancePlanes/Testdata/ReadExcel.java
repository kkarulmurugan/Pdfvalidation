package com.InsurancePlanes.Testdata;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;

public class ReadExcel {

    XSSFWorkbook workbook;
    public XSSFSheet MazdaNew;
    Iterator<Row> rows;
    public int  numberOfRows;
   public int NmberOfColunms;

    public String ReadData(int row, int col) throws Exception {
        String path = "C://Users//ismaile//Desktop//Toyota//InsurenceServicing_TestDataSheet_v1.1.xlsx";
        File file = new File(path);

        FileInputStream fis = new FileInputStream(file);

        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet MazdaNew = workbook.getSheetAt(1);


         numberOfRows = MazdaNew.getLastRowNum();
         NmberOfColunms =  MazdaNew.getRow(0).getLastCellNum();
        return MazdaNew.getRow(row).getCell(col).getStringCellValue();


   }

    public String ContractCreateData(int row, int col) throws Exception {
        String path = "C://Users//ismaile//Desktop//Toyota//Contract_Create_Data_MazdaNew.xlsx";
        File file = new File(path);

        FileInputStream fis = new FileInputStream(file);

        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet MazdaNew = workbook.getSheetAt(0);


        numberOfRows = MazdaNew.getLastRowNum();
        NmberOfColunms =  MazdaNew.getRow(0).getLastCellNum();
        return MazdaNew.getRow(row).getCell(col).getStringCellValue();


    }


}

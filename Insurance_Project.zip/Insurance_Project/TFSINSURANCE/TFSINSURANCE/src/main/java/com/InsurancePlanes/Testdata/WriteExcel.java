package com.InsurancePlanes.Testdata;

import net.sf.jxls.reader.XLSReadStatus;
import net.sf.jxls.reader.XLSReader;
import net.sf.jxls.reader.XLSSheetReader;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class WriteExcel {

    public void extractDateToExcel(){

        XLSReader reader = new XLSReader() {
            @Override
            public XLSReadStatus read(InputStream inputStream, Map map) throws IOException {
                return null;
            }

            @Override
            public void setSheetReaders(Map map) {

            }

            @Override
            public Map getSheetReaders() {
                return null;
            }

            @Override
            public void addSheetReader(String s, XLSSheetReader xlsSheetReader) {

            }

            @Override
            public void addSheetReader(XLSSheetReader xlsSheetReader) {


            }
        };





    }
}

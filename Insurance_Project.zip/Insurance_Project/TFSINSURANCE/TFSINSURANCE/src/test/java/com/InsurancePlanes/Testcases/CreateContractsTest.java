package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.CreateContracts;
import com.InsurancePlanes.Pages.ExtractData;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.LoginPage;
import com.InsurancePlanes.Testdata.ReadExcel;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CreateContractsTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;
    ReadExcel MazdaNewVin;
    CreateContracts createcontracts;

    public CreateContractsTest(){
        super();

    }

    @BeforeClass
    public void setUp() throws InterruptedException {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));
        createcontracts = new CreateContracts();

    }


    @Test
    public void CreateContracts() throws Exception {

        MazdaNewVin = new ReadExcel();


        for (int i = 1; i < 142; i++) {
            Thread.sleep(2000);
            homePage.getContracts();
            Thread.sleep(2000);
            homePage.clickOnQuickRater();
            Thread.sleep(2000);
            homePage.VinNumber(MazdaNewVin.ContractCreateData(i,2));
            homePage.getOdometer(MazdaNewVin.ContractCreateData(i,3));
            homePage.getPurchaseType(MazdaNewVin.ContractCreateData(i,4));
            homePage.getPurchaseDate(MazdaNewVin.ContractCreateData(i,5));
            homePage.getPurchasePrice(MazdaNewVin.ContractCreateData(i,6));
            homePage.getInServiceDate(MazdaNewVin.ContractCreateData(i,7));
            homePage.getFinanceAmount(MazdaNewVin.ContractCreateData(i,8));
            homePage.getFinanceLength(MazdaNewVin.ContractCreateData(i,10));
            homePage.getFinanceType(MazdaNewVin.ContractCreateData(i,9));
            homePage.getMSRP(MazdaNewVin.ContractCreateData(i,11));
            homePage.getDealer(MazdaNewVin.ContractCreateData(i,12));
            homePage.getGetRates();
            createcontracts.programs();


            //ppm
            createcontracts.getPPM();
            createcontracts.getCustomerFirstName(MazdaNewVin.ContractCreateData(i,14));
            createcontracts.getcustomerLastName(MazdaNewVin.ContractCreateData(i,15));
            createcontracts.getCustomerBusinessName(MazdaNewVin.ContractCreateData(i,16));
            createcontracts.getCustomerAddress1(MazdaNewVin.ContractCreateData(i,17));
            createcontracts.getCustomerAddress2(MazdaNewVin.ContractCreateData(i,18));
            createcontracts.getCustomerZip(MazdaNewVin.ContractCreateData(i,19));
            createcontracts.getCustomerPhone(MazdaNewVin.ContractCreateData(i,20));
            createcontracts.getCoBuyerFirstName(MazdaNewVin.ContractCreateData(i,21));
            createcontracts.getCoBuyerLastName(MazdaNewVin.ContractCreateData(i,22));
            createcontracts.getCoBuyerAddressLine1(MazdaNewVin.ContractCreateData(i,23));
            createcontracts.getCoBuyerAddressLine2(MazdaNewVin.ContractCreateData(i,24));
            createcontracts.getCoBuyerZip(MazdaNewVin.ContractCreateData(i,25));
            createcontracts.getCoBuyerPhone(MazdaNewVin.ContractCreateData(i,26));
            createcontracts.getLienHolderName(MazdaNewVin.ContractCreateData(i,27));
            createcontracts.getMFS();
            Thread.sleep(2000);
            createcontracts.getEntercontractAndFinalize();
            Thread.sleep(2000);
            createcontracts.getdublicatecontract();
            Thread.sleep(2000);
            createcontracts.getterm2();


            //VCS
            Thread.sleep(10000);
            createcontracts.getVSC();


            //GAP
            createcontracts.getGAP();

            //ANC
            createcontracts.getANC();

            //New customer
            createcontracts.getSellContractforNewCustomer();










        }
    }
}

package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.ExtractData;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.LoginPage;
import com.InsurancePlanes.Testdata.ListenerTest;
import com.InsurancePlanes.Testdata.ReadExcel;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerTest.class)
public class HomePageTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;
    ReadExcel MazdaNewVin;

    public HomePageTest(){
        super();

    }

    @BeforeClass
    public void setUp() throws InterruptedException {
        initialization();
        loginPage = new LoginPage();
       homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));

        //homePage = new HomePage();

    }


    @Test
    public void EnterVinNumberTest() throws Exception {

        MazdaNewVin = new ReadExcel();


        for (int i = 114; i < 142; i++) {
            homePage.clickOnQuickRater();
            Thread.sleep(2000);
            homePage.VinNumber(MazdaNewVin.ReadData(i,2));

            homePage.getOdometer(MazdaNewVin.ReadData(i,3));
            homePage.getPurchaseType(MazdaNewVin.ReadData(i,4));
            homePage.getPurchaseDate(MazdaNewVin.ReadData(i,5));
            homePage.getPurchasePrice(MazdaNewVin.ReadData(i,6));
            homePage.getInServiceDate(MazdaNewVin.ReadData(i,7));
            homePage.getFinanceAmount(MazdaNewVin.ReadData(i,8));
            homePage.getFinanceLength(MazdaNewVin.ReadData(i,10));
            homePage.getFinanceType(MazdaNewVin.ReadData(i,9));
            homePage.getMSRP(MazdaNewVin.ReadData(i,11));
            homePage.getDealer(MazdaNewVin.ReadData(i,12));
            homePage.getGetRates();
            ExtractData.dataExtraction();
//            homePage.getPlansList();
//            homePage.getPPM();
//            homePage.getPlans();
//            homePage.getForm();
//            homePage.getViewDraftdoc();
//            homePage.getCloseViewDraftDocument();
//            homePage.getEnterContractandFinalize();
//            homePage.getSuccess_PrintAvailableDocs();
//            homePage.getSuccess_ClosePrintAvailableDocs();
//            homePage.getSuccess_SellAnotherContractToSameCustomer();
//            homePage.getSuccess_SellAnotherContractToSameCustomer_Selectplan();



        }
    }


    //    @AfterClass
//    public void tearDown(){
//
//        driver.quit();
//    }
}

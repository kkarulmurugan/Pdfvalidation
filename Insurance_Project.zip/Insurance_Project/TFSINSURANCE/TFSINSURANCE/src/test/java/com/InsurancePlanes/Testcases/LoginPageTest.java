package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.LoginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.*;

public class LoginPageTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;

    public LoginPageTest(){
        super();

    }

    @BeforeClass
    public void setUp() throws InterruptedException {
        initialization();
        loginPage = new LoginPage();

    }


   @Test(priority = 0)
    public void LoginPageTitleTest(){
       String title =  loginPage.validatePageTitle();
       System.out.println(title);

       // Assert.assertEquals(title, "SEcureAdmin Login");
    }

    @Test(priority = 1)
    public void loginTest() throws InterruptedException {

       homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));
    }



//    @AfterClass
//    public void tearDown(){
//
//        driver.quit();
//    }

}

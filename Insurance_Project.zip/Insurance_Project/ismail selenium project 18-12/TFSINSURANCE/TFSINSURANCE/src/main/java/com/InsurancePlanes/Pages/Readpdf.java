package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.testautomationguru.utility.CompareMode;
import com.testautomationguru.utility.PDFUtil;
import de.redsix.pdfcompare.CompareResult;
import de.redsix.pdfcompare.CompareResultWithPageOverflow;
import de.redsix.pdfcompare.PageArea;
import de.redsix.pdfcompare.PdfComparator;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.testng.annotations.Test;

import java.io.*;
import java.nio.file.Path;


public class Readpdf extends TestBase {

    @Test
    public void PDF() throws IOException {
        String path = "C:\\Users\\ismaile\\Desktop\\Contract for contract P00000567.pdf";
        File file = new File(path);
        FileInputStream fileInputStream = new FileInputStream(file);

        BufferedInputStream fielParse = new BufferedInputStream(fileInputStream);
        PDDocument document = null;
        document = PDDocument.load(fielParse);
        String pdfContent = new PDFTextStripper().getText(document);

        System.out.println(pdfContent);
    }

    public void getpdfUtil() throws Exception {
        PDFUtil pdfUtil = new PDFUtil();

        pdfUtil.getPageCount("c:/sample.pdf");
        //returns the pdf content - all pages
        pdfUtil.getText("c:/sample.pdf");

// returns the pdf content from page number 2
        pdfUtil.getText("c:/sample.pdf", 2);

// returns the pdf content from page number 5 to 8
        pdfUtil.getText("c:/sample.pdf", 5, 8);
        //set the path where we need to store the images
        pdfUtil.setImageDestinationPath("c:/imgpath");
        pdfUtil.extractImages("c:/sample.pdf");

// extracts and saves the pdf content from page number 3
        pdfUtil.extractImages("c:/sample.pdf", 3);

// extracts and saves the pdf content from page 2
        pdfUtil.extractImages("c:/sample.pdf", 2, 2);
        //set the path where we need to store the images
        pdfUtil.setImageDestinationPath("c:/imgpath");
        pdfUtil.savePdfAsImage("c:/sample.pdf");
        String file1 = "c:/files/doc1.pdf";
        String file2 = "c:/files/doc2.pdf";

// compares the pdf documents and returns a boolean
// true if both files have same content. false otherwise.
        pdfUtil.compare(file1, file2);

// compare the 3rd page alone
        pdfUtil.compare(file1, file2, 3, 3);

// compare the pages from 1 to 5
        pdfUtil.compare(file1, file2, 1, 5);

        //pass all the possible texts to be removed before comparing
        pdfUtil.excludeText("1998", "testautomation");

//pass regex patterns to be removed before comparing
// \\d+ removes all the numbers in the pdf before comparing
        pdfUtil.excludeText("\\d+");

// compares the pdf documents and returns a boolean
// true if both files have same content. false otherwise.
        pdfUtil.compare(file1, file2);

// compare the 3rd page alone
        pdfUtil.compare(file1, file2, 3, 3);

// compare the pages from 1 to 5
        pdfUtil.compare(file1, file2, 1, 5);
        // compares the pdf documents and returns a boolean
// true if both files have same content. false otherwise.
// Default is CompareMode.TEXT_MODE
        pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
        pdfUtil.compare(file1, file2);

// compare the 3rd page alone
        pdfUtil.compare(file1, file2, 3, 3);

// compare the pages from 1 to 5
        pdfUtil.compare(file1, file2, 1, 5);

//if you need to store the result
        pdfUtil.highlightPdfDifference(true);
        pdfUtil.setImageDestinationPath("c:/imgpath");
        pdfUtil.compare(file1, file2);


    }

    public void getPDFCompare() throws Exception {

        //https://github.com/red6/pdfcompare
        new PdfComparator("expected.pdf", "actual.pdf").compare().writeTo("diffoutput");

        final CompareResult result = new PdfComparator("expected.pdf", "actual.pdf").compare();
        if (result.isNotEqual()) {
            System.out.println("Differences found!");
        }
        if (result.isEqual()) {
            System.out.println("No Differences found!");
        }
        if (result.hasDifferenceInExclusion()) {
            System.out.println("Differences in excluded areas found!");
        }
        result.getDifferences(); // returns page areas, where differences were found

        boolean isEquals = new PdfComparator("expected.pdf", "actual.pdf").compare().writeTo("diffOutput");
        if (!isEquals) {
            System.out.println("Differences found!");
        }

        String ignorefile = "C:\\Users\\ismaile\\IdeaProjects\\TFSINSURANCE\\src\\main\\java\\com\\InsurancePlanes\\Config\\ignore.conf";
        new PdfComparator("expected.pdf", "actual.pdf").withIgnore(ignorefile).compare();

        //Alternatively an Exclusion can be added via the API as follows:

        new PdfComparator("expected.pdf", "actual.pdf")
                .withIgnore((Path) new PageArea(1, 230, 350, 450, 420))
                .withIgnore((Path) new PageArea(2))
                .compare();

        //Encrypted PDF files

        new PdfComparator("expected.pdf", "actual.pdf")
                .withExpectedPassword("somePwd")
                .withActualPassword("anotherPwd")
                .compare();

        //memory consumption is a problem, a CompareResultWithPageOverflow or a CompareResultWithMemoryOverflow can be used.
        //A different CompareResult implementation can be used as follows:
        new PdfComparator("expected.pdf", "actual.pdf", new CompareResultWithPageOverflow()).compare();
    }

    public void getItextpdf() {
        //https://www.mkyong.com/java/itext-read-and-write-pdf-in-java/
//1. iText – Write PDF
        //2. iText – Read PDF
        //PdfReader reader;
        PdfReader reader;

        try {

            reader = new PdfReader("f:/itext.pdf");


            // pageNumber = 1
//            String textFromPage = PdfTextExtractor.getTextFromPage(reader,1);
//                  //  PdfTextExtractor.getTextFromPage(reader,1);
//
//            System.out.println(textFromPage);

            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}

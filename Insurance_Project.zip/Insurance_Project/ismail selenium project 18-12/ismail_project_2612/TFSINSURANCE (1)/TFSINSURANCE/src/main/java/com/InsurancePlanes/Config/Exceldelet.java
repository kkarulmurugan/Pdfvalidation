package com.InsurancePlanes.Config;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Exceldelet {
    public static void main(String[] args) throws Exception {
        String path = "C:/Users/ismaile/Desktop/InsurenceServicing_TestDataSheet.xlsx";
        File file = new File(path);

	        FileInputStream fis = new FileInputStream(file);



	        XSSFWorkbook workbook = new XSSFWorkbook(fis);
	        XSSFSheet MazdaNew = workbook.getSheetAt(1);

	         int numberOfRows = MazdaNew.getLastRowNum();
	         int NmberOfColunms =  MazdaNew.getRow(0).getLastCellNum();

	         System.out.println("Number of roows " +numberOfRows);
        System.out.println("Workbook has " + workbook.getNumberOfSheets() + " Sheets : ");

        System.out.println(MazdaNew.getRow(1).getCell(2).getStringCellValue());
    }
}

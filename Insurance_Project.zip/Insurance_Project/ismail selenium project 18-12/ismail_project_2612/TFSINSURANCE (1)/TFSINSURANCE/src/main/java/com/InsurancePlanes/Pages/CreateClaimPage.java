package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.security.Key;

public class CreateClaimPage extends TestBase {

    public void createPPMClaim(){


        //Go contracts..............ready on the other classes
        //Go find contracts..............ready on the other classes
        //Go send contract number..............ready on the other classes
        WebElement ContractNumber = driver.findElement(By.xpath("//*[@name = 'contractNumber']"));
        ContractNumber.sendKeys("p00000128", Keys.ENTER);

        WebElement PPMAutoCare = driver.findElement(By.xpath("//*[. = 'Auto Care']"));
        PPMAutoCare.click();

        WebElement selectClaim = driver.findElement(By.xpath("//li[. = 'Claims']"));
        selectClaim.click();

        WebElement AddClaim = driver.findElement(By.xpath("//span[. = 'Add Claim']"));
        AddClaim.click();

        WebElement rfSearchButton = driver.findElement(By.xpath("//button[contains(@id,'rfSearchButton_')]"));
        rfSearchButton.click();

        WebElement EnterDealerName = driver.findElement(By.xpath("//input[contains(@id,'gs_Name')]"));
        EnterDealerName.sendKeys("Fremont", Keys.ENTER);

        WebElement selecetDealer = driver.findElement(By.xpath("//td[contains(@title,'Fremont')]"));
        selecetDealer.click();

        WebElement ContactName = driver.findElement(By.xpath("//input[contains(@name,'Contact_')]"));
        ContactName.sendKeys("TestAutomation1234567");

        WebElement ClaimOdometer = driver.findElement(By.xpath("//input[contains(@name,'Claim.Odometer')]"));
        ClaimOdometer.sendKeys("1600");

        WebElement ClaimRepairOrderNumber = driver.findElement(By.xpath("//input[contains(@name,'Claim.RepairOrderNumber')]"));
        ClaimRepairOrderNumber.sendKeys("1720");

        WebElement PrimaryPayeeDropDown = driver.findElement(By.xpath("//span[contains(@id,'PaidTo_')]"));
        PrimaryPayeeDropDown.click();

        WebElement PrimaryPayeeCustomer = driver.findElement(By.xpath("//div[. = 'Customer']"));
        PrimaryPayeeCustomer.click();

        WebElement SaveClose = driver.findElement(By.xpath("//button[. = 'Save & Close']"));
        SaveClose.click();
    }
}

package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class CreateContracts extends TestBase {

    public FileInputStream inputStream;
    public XSSFWorkbook workbook;
    public Row row;
    public XSSFSheet sheet;
    public int lastRow;

    public void extractDateToExcel() throws Exception {

        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
        inputStream = new FileInputStream(new File(excelFilePath));
        workbook = new XSSFWorkbook(inputStream);
        sheet = workbook.getSheetAt(0);
        lastRow = sheet.getLastRowNum();
        row = sheet.createRow(++lastRow);

//row.createCell(24).setCellValue(PPMSuggestedRetailPrice.getText());
        // row = sheet.createRow(++lastRow);





    }

    String [] PlanTypes;

    public CreateContracts() throws Exception {
        PageFactory.initElements(driver, this);
        excel.extractDateToExcel();
    }


    public void programs() {
        //programs
        List<WebElement> PlanTypes1 = driver.findElements(By.xpath("//table[@class = 'quickRaterResults ui-jqgrid-btable ui-common-table']//tr"));
        PlanTypes = new String[PlanTypes1.size()];
        for(int i =0; i < PlanTypes1.size();i++){
            PlanTypes[i] = PlanTypes1.get(i).getText();
        }


    }

    @FindBy(xpath = "//*[@id='13']/td[2]")
    WebElement OpenPPM;
    @FindBy(xpath = "//tr[@id = '650']/td[1]")
    WebElement term1;
    @FindBy(xpath = "//h3[. = 'Form']")
    WebElement Form;
    //Customer fill form
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.FirstName']")
    WebElement customerFirstName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.LastName']")
    WebElement customerLastName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BusinessName']")
    WebElement CustomerBusinessName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.AddressLine1']")
    WebElement CustomerAddress1;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.AddressLine2']")
    WebElement CustomerAddress2;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.ZipCode']")
    WebElement CustomerZip;
    @FindBy(xpath = "//*[@name = 'ContractRequest.Customer.BillingAddress.Phone']")
    WebElement CustomerPhone;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.FirstName']")
    WebElement CoBuyerFirstName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.LastName']")
    WebElement CoBuyerLastName;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.AddressLine1']")
    WebElement CoBuyerAddressLine1;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.AddressLine2']")
    WebElement CoBuyerAddressLine2;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.ZipCode']")
    WebElement CoBuyerZip;
    @FindBy(xpath = "//*[@name = 'ContractRequest.CoBuyer.BillingAddress.Phone']")
    WebElement CoBuyerPhone;
    @FindBy(xpath = "//*[@name = 'ContractRequest.LienHolder.Name']")
    WebElement LienHolderName;
    @FindBy(xpath = "//button[.='Enter Contract and Finalize']")
    WebElement EntercontractAndFinalize;
    @FindBy(xpath = "//*[.='Duplicate Contract']")
    WebElement dublicatecontract;
    @FindBy(xpath = "//*[.='Force']")
    WebElement Force;
    @FindBy(xpath = "//*[.='Sell Another Contract to Same Customer']")
    WebElement SellAnotherContracttoSameCustomer;
    @FindBy(xpath = "//td[contains(text(),'2 YRS/ 3 SERVICES')]")
    WebElement term2;
    @FindBy(xpath = "//div[contains(@id,'lienDropDown')]/div[1]/div[2]")
    WebElement MFS;
    @FindBy(xpath = "//input[contains(@name,'deductibleInput_')]")
    WebElement deductibleInput;
    @FindBy(xpath = "//*[.='Sell Contract for New Customer']")
    WebElement SellContractforNewCustomer;
    @FindBy(css = "#Contracts-QuickRater")
    WebElement QuickRater;

    @FindBy(xpath = "//input[@name = 'VIN']")
    WebElement VinNumber;

    @FindBy(xpath = "//input[@name = 'ModelObject.Odometer']")
    WebElement Odometer;

    @FindBy(xpath = "//label[text()[. = 'Purchase Type']]/..//span[contains(@class, 'icon-triangle')]")
    WebElement purchaseType;

    @FindBy(xpath = "//div[text()[. = 'New']]")
    WebElement purchaseTypeSelect;

    @FindBy(xpath = "//input[@name = 'ModelObject.VehiclePurchaseDate']")
    WebElement purchaseDate;

    @FindBy(xpath = "//input[@name = 'ModelObject.PurchasePrice']")
    WebElement PurchasePrice;

    @FindBy(xpath = "//input[@name = 'ModelObject.InserviceDate']")
    WebElement InServiceDate;

    @FindBy(xpath = "//input[@name = 'ModelObject.FinanceAmount']")
    WebElement FinanceAmount;

    @FindBy(xpath = "//input[@name = 'ModelObject.FinanceLength']")
    WebElement FinanceLength;

    @FindBy(xpath = "//div[@name = 'ModelObject.FinanceType']/span")
    WebElement FinanceType;

    @FindBy(xpath = "//div[@name = 'ModelObject.FinanceType']")
    WebElement FinanceTypeSelect;

    @FindBy(xpath = "//input[@name = 'ModelObject.MSRP']")
    WebElement MSRP;

    @FindBy(xpath = "//div[@name = 'DealerId']/span[1]/span")
    WebElement SelectDealerDropDown;

    @FindBy(xpath = "//div[@name = 'DealerId']/input[2]")
    WebElement SelectDealer;

    @FindBy(xpath = "//div[@class = 'ui-widget-content ui-corner-bottom']/div[1]/div[2]")
    WebElement SelectDealerLeft;


    @FindBy(xpath = "//button[text()[. = 'Get Rates']]")
    WebElement GetRates;
    @FindBy(xpath = "//h3[.='Contracts']")
    WebElement Contracts;
    public void getContracts(){
        Contracts.click();
    }
    public void clickOnQuickRater(){
        QuickRater.click();
    }

    public void VinNumber(String str)  {

        VinNumber.click();

        VinNumber.sendKeys(str);
        row.createCell(2).setCellValue(str);
    }

    public void getOdometer(String odo){
        Odometer.click();
        Odometer.sendKeys(odo);
        row.createCell(3).setCellValue(odo);
    }

    public void getPurchaseType( String PurchaseT){
        purchaseType.click();
        driver.findElement(By.xpath("//div[text() = '"+PurchaseT+"']")).click();
        //purchaseTypeSelect.click();
        row.createCell(4).setCellValue(PurchaseT);
    }

    public void getPurchaseDate(String date){

        purchaseDate.sendKeys(Keys.BACK_SPACE,date);
        //leave date picker
        Odometer.click();
        row.createCell(5).setCellValue(date);
    }

    public void getPurchasePrice(String price){
        PurchasePrice.sendKeys(price);
        row.createCell(6).setCellValue(price);
    }

    public void getInServiceDate(String inservicedate){

        InServiceDate.sendKeys(Keys.BACK_SPACE,inservicedate);
        row.createCell(7).setCellValue(inservicedate);
    }

    public void getFinanceAmount(String amount){
        FinanceAmount.sendKeys(amount);
        row.createCell(8).setCellValue(amount);
    }

    public void getFinanceType(String Financet) throws InterruptedException {


        driver.findElement(By.xpath("//div[@name = 'ModelObject.FinanceType']/span/span")).click();

        driver.findElement(By.xpath("//div[text() = '"+Financet+"']")).click();
        row.createCell(9).setCellValue(Financet);

    }

    public void getFinanceLength(String length){
        FinanceLength.sendKeys(length);
        row.createCell(10).setCellValue(length);
    }



    public void getMSRP(String msrp){
        MSRP.sendKeys(msrp);
        row.createCell(11).setCellValue(msrp);
    }

    public void getDealer(String dealer) throws InterruptedException {

        SelectDealerDropDown.click();
        //emSelectDealer.click();
        SelectDealer.clear();
        Thread.sleep(2000);
        SelectDealer.sendKeys(dealer);
        Thread.sleep(2000);
        SelectDealerLeft.click();
        row.createCell(12).setCellValue(dealer);
    }

    public void getGetRates() throws Exception {
        GetRates.click();
    }


    public void getPPM() {

        for (String plans : PlanTypes) {
            System.out.println("ppm: " + plans);

            if (plans.equalsIgnoreCase("PPM Auto Care Auto Care PPM")) {
                OpenPPM.click();

                WebElement PPMType = driver.findElement(By.xpath("//td[contains(text(),'PPM')][1]"));
                row.createCell(25).setCellValue(PPMType.getText());

                WebElement PPMPlan = driver.findElement(By.xpath("//td[contains(text(),'Auto Care')][1]"));
                row.createCell(26).setCellValue(PPMPlan.getText());

                WebElement PPMProduct = driver.findElement(By.xpath("//td[contains(text(),'Auto Care')][2]"));
                row.createCell(27).setCellValue(PPMProduct.getText());

                WebElement PPMPogram = driver.findElement(By.xpath("//td[contains(text(),'PPM')][2]"));
                row.createCell(28).setCellValue(PPMPogram.getText());

                WebElement PPMterm1 = driver.findElement(By.xpath("//tr[@id = '650']/td[1]"));
                row.createCell(29).setCellValue(PPMterm1.getText());

                WebElement PPMLimit1 = driver.findElement(By.xpath("//tr[@id = '650']/td[2]"));
                row.createCell(30).setCellValue(PPMLimit1.getText());

                WebElement PPMClassCode = driver.findElement(By.xpath("//tr[@id = '650']/td[3]"));
                row.createCell(31).setCellValue(PPMClassCode.getText());

                WebElement PPMRateId = driver.findElement(By.xpath("//tr[@id = '650']/td[4]"));
                row.createCell(32).setCellValue(PPMRateId.getText());

                WebElement PPMSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '650']/td[5]"));
                row.createCell(33).setCellValue(PPMSuggestedRetailPrice.getText());

                term1.click();
                Form.click();
            }
        }
    }

    public void getCustomerFirstName(String CustomerFirstName) {
        customerFirstName.sendKeys(CustomerFirstName);
        row.createCell(11).setCellValue(CustomerFirstName);
    }

    public void getcustomerLastName(String CustomerLastName) {
        customerLastName.sendKeys(CustomerLastName);
        row.createCell(12).setCellValue(CustomerLastName);
    }

    public void getCustomerBusinessName(String customerBusinessName) {
        CustomerBusinessName.sendKeys(customerBusinessName);
        row.createCell(13).setCellValue(customerBusinessName);
    }

    public void getCustomerAddress1(String customerAddress1) {
        CustomerAddress1.sendKeys(customerAddress1);
        row.createCell(14).setCellValue(customerAddress1);
    }

    public void getCustomerAddress2(String customerAddress2) {
        CustomerAddress2.sendKeys(customerAddress2);
        row.createCell(15).setCellValue(customerAddress2);
    }

    public void getCustomerZip(String customerZip) {
        CustomerZip.sendKeys(customerZip);
        row.createCell(16).setCellValue(customerZip);
    }

    public void getCustomerPhone(String customerPhone) {
        CustomerPhone.sendKeys(customerPhone);
        row.createCell(17).setCellValue(customerPhone);
    }

    public void getCoBuyerFirstName(String coBuyerFirstName) {
        CoBuyerFirstName.sendKeys(coBuyerFirstName);
        row.createCell(18).setCellValue(coBuyerFirstName);
    }

    public void getCoBuyerLastName(String coBuyerLastName) {
        CoBuyerLastName.sendKeys(coBuyerLastName);
        row.createCell(19).setCellValue(coBuyerLastName);
    }

    public void getCoBuyerAddressLine1(String coBuyerAddressLine1) {
        CoBuyerAddressLine1.sendKeys(coBuyerAddressLine1);
        row.createCell(20).setCellValue(coBuyerAddressLine1);
    }

    public void getCoBuyerAddressLine2(String coBuyerAddressLine2) {
        CoBuyerAddressLine2.sendKeys(coBuyerAddressLine2);
        row.createCell(21).setCellValue(coBuyerAddressLine2);
    }

    public void getCoBuyerZip(String coBuyerZip) {
        CoBuyerZip.sendKeys(coBuyerZip);
        row.createCell(22).setCellValue(coBuyerZip);
    }

    public void getCoBuyerPhone(String coBuyerPhone) {
        CoBuyerPhone.sendKeys(coBuyerPhone);
        row.createCell(23).setCellValue(coBuyerPhone);
    }

    public void getLienHolderName(String lienHolderName) {
        LienHolderName.sendKeys(lienHolderName);
        row.createCell(24).setCellValue(lienHolderName);
    }

    public void getMFS() {
        MFS.click();
    }

    public void getEntercontractAndFinalize() {
        EntercontractAndFinalize.click();
    }

    public void getdublicatecontract() {
      String dublicateContract = driver.findElements(By.xpath("//*[.='Duplicate Contract']")).get(0).getText();
        if (dublicateContract.equalsIgnoreCase("Duplicate Contract")) {
            Force.click();
        }
    }


    //give 3 seconds wait time
    public void getSellAnotherContracttoSameCustomer() {
        SellAnotherContracttoSameCustomer.click();
    }

    public void getterm2() {
        row = sheet.createRow(++lastRow);
        SellAnotherContracttoSameCustomer.click();
        row.createCell(30).setCellValue(term2.getText());
        term2.click();
        EntercontractAndFinalize.click();
        getdublicatecontract();
    }

    @FindBy(xpath = "//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")
    WebElement POSDollarWATerm1;
    @FindBy(xpath = "//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153' ]/td[1]")
    WebElement POSNonInsuredTerm1;
    @FindBy(xpath = "//tr[@id = 'VSC New POS Platinum VSA (TMIS 1st Dollar) VSA' ]/td[1]")
    WebElement POSDollarTerm1;
    @FindBy(xpath = "//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")
    WebElement WindowDollarWATerm1;
    @FindBy(xpath = "//*[@id='VSC New Window Platinum VSA (TMIS Surety CLP) VSA']/td[1]")
    WebElement WindowSuretyCLPTerm1;
    @FindBy(xpath = "//tr[@id = 'VSC New Window Platinum VSA (TMIS 1st Dollar) VSA']/td[1]")
    WebElement WindowDollarTerm1;
    @FindBy(xpath = "//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]")
    WebElement WindowNonInsuredTerm1;
    @FindBy(xpath = "//*[@id='981' or @id = '982' or @id = '983']/td[1]")
    WebElement POSInsuredFLTerm1;
    @FindBy(xpath = "//*[@id='999' or @id = '1000' or @id = '1001']/td[1]")
    WebElement WindowInsuredFLTerm1;
    @FindBy(xpath = "//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]")
    WebElement PlatinumNonInsuredTerm1;
    @FindBy(xpath = "//*[@id='1202']/td[1]")
    WebElement PlatinumInsuredFLTerm1;
    @FindBy(xpath = "//*[@id='pos']")
    WebElement POSSuretyCLPTerm1;
    @FindBy(xpath = "//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[1]")
    WebElement UsedGoldNonInsuredTerm1;
    @FindBy(xpath = "//*[@id='938' or @id = '939' or @id = '937']/td[1]")
    WebElement UsedPlatinumNonInsuredTerm1;

    public void getVSC() throws Exception {
        for (String plans : PlanTypes) {

            System.out.println( "vsc: "+ plans );

            if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar WA) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='149']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWAType = driver.findElement(By.xpath("//*[@id='149']/td[2]"));
                row.createCell(25).setCellValue(VSCWAType.getText());

                WebElement VSCWAPlan = driver.findElement(By.xpath(" //*[@id='149']/td[3]"));
                row.createCell(26).setCellValue(VSCWAPlan.getText());

                WebElement VSCWAProduct = driver.findElement(By.xpath("//*[@id='149']/td[4]"));
                row.createCell(27).setCellValue(VSCWAProduct.getText());

                WebElement VSCWAPogram = driver.findElement(By.xpath("//*[@id='149']/td[5]"));
                row.createCell(28).setCellValue(VSCWAPogram.getText());
                WebElement VSCWAterm1 = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]"));
                row.createCell(29).setCellValue(VSCWAterm1.getText());

                WebElement VSCWALimit1 = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[2]"));
                row.createCell(30).setCellValue(VSCWALimit1.getText());

                WebElement VSCWAClassCode = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[3]"));
                row.createCell(31).setCellValue(VSCWAClassCode.getText());

                WebElement VSCWARateId = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[4]"));
                row.createCell(32).setCellValue(VSCWARateId.getText());

                WebElement VSCWASuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[5]"));
                row.createCell(33).setCellValue(VSCWASuggestedRetailPrice.getText());

                POSDollarWATerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWAterm2 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[1]"));
                row.createCell(29).setCellValue(VSCWAterm2.getText());

                WebElement VSCWALimit2 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[2]"));
                row.createCell(30).setCellValue(VSCWALimit2.getText());

                WebElement VSCWAClassCode1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[3]"));
                row.createCell(31).setCellValue(VSCWAClassCode1.getText());

                WebElement VSCWARateId1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[4]"));
                row.createCell(32).setCellValue(VSCWARateId1.getText());

                WebElement VSCWASuggestedRetailPrice1 = driver.findElement(By.xpath("//*[@id='1319' or @id = '1320' or @id = '1321' or @id = '1318']/td[5]"));
                row.createCell(33).setCellValue(VSCWASuggestedRetailPrice1.getText());
                System.out.println();

                VSCWAterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();


                driver.findElement(By.xpath("//*[@id='71']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath("//td[contains(text(),'VSC')][1][position()=1]"));
                row.createCell(25).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath("//td[contains(text(),'New POS Platinum')][1][position()=1]"));
                row.createCell(26).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath("//td[contains(text(),'VSA (TMIS Non-Insured)')][1][position()=1]"));
                row.createCell(27).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath("//tr[@id = '71']/td[5]"));
                row.createCell(28).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[1]"));
                row.createCell(29).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[2]"));
                row.createCell(30).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[3]"));
                row.createCell(31).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[4]"));
                row.createCell(32).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886']/td[5]"));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice.getText());



                POSNonInsuredTerm1.click();
                deductibleInput.click();
                Form.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[1]"));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[2]"));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[3]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[4]"));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath("//tr[@id = '887' or @id = '888' or @id = '899' or @id = '896']/td[5]"));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());


                VSCterm2.click();

                deductibleInput.click();
                Form.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS 1st Dollar) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath(""));
                row.createCell(25).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath(""));
                row.createCell(26).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath(""));
                row.createCell(27).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath(""));
                row.createCell(28).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath(""));
                row.createCell(31).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice.getText());

                POSDollarTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar WA) VSA")) {
                row = sheet.createRow(++lastRow);
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='148']/td[2]")).click();
                row.createCell(13).setCellValue(WindowDollarWATerm1.getText());
                WindowDollarWATerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Surety CLP) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath(""));
                row.createCell(25).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath(""));
                row.createCell(26).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath(""));
                row.createCell(27).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath(""));
                row.createCell(28).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath(""));
                row.createCell(31).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice.getText());

                POSDollarTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS 1st Dollar) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='80' or @id = 'clp']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath(""));
                row.createCell(25).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath(""));
                row.createCell(26).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath(""));
                row.createCell(27).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath(""));
                row.createCell(28).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath(""));
                row.createCell(31).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice.getText());

                POSDollarTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='70']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCWType = driver.findElement(By.xpath("//tr[@id = '70']/td[2]"));
                row.createCell(25).setCellValue(VSCWType.getText());

                WebElement VSCWPlan = driver.findElement(By.xpath("//tr[@id = '70']/td[3]"));
                row.createCell(26).setCellValue(VSCWPlan.getText());

                WebElement VSCWProduct = driver.findElement(By.xpath("//tr[@id = '70']/td[4]"));
                row.createCell(27).setCellValue(VSCWProduct.getText());

                WebElement VSCWPogram = driver.findElement(By.xpath("//tr[@id = '70']/td[5]"));
                row.createCell(28).setCellValue(VSCWPogram.getText());

                WebElement VSCWterm1 = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]"));
                row.createCell(29).setCellValue(VSCWterm1.getText());

                WebElement VSCWLimit1 = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[2]"));
                row.createCell(30).setCellValue(VSCWLimit1.getText());

                WebElement VSCWClassCode = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[3]"));
                row.createCell(31).setCellValue(VSCWClassCode.getText());

                WebElement VSCWRateId = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[4]"));
                row.createCell(32).setCellValue(VSCWRateId.getText());

                WebElement VSCWSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[5]"));
                row.createCell(33).setCellValue(VSCWSuggestedRetailPrice.getText());

                WindowNonInsuredTerm1.click();
                deductibleInput.click();
                Form.click();
                Thread.sleep(2000);
                EntercontractAndFinalize.click();
                Thread.sleep(2000);
                getdublicatecontract();
                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='126']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCFLType = driver.findElement(By.xpath("//*[@id='126']/td[2]"));
                row.createCell(25).setCellValue(VSCFLType.getText());

                WebElement CSVFLPlan = driver.findElement(By.xpath("//*[@id='126']/td[3]"));
                row.createCell(26).setCellValue(CSVFLPlan.getText());

                WebElement CVSFLProduct = driver.findElement(By.xpath("//*[@id='126']/td[4]"));
                row.createCell(27).setCellValue(CVSFLProduct.getText());

                WebElement CSVFLPogram = driver.findElement(By.xpath("//*[@id='126']/td[5]"));
                row.createCell(28).setCellValue(CSVFLPogram.getText());

                WebElement CSVFLterm1 = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[1]"));
                row.createCell(29).setCellValue(CSVFLterm1.getText());

                WebElement CSVFLLimit1 = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[2]"));
                row.createCell(30).setCellValue(CSVFLLimit1.getText());

                WebElement CSVFLClassCode = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[3]"));
                row.createCell(31).setCellValue(CSVFLClassCode.getText());

                WebElement CSVFLRateId = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[4]"));
                row.createCell(32).setCellValue(CSVFLRateId.getText());

                WebElement CSVFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='981' or @id = '982' or @id = '983']/td[5]"));
                row.createCell(33).setCellValue(CSVFLSuggestedRetailPrice.getText());


                POSInsuredFLTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();
                row = sheet.createRow(++lastRow);
                WebElement CSVFLterm2 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[1]"));
                row.createCell(29).setCellValue(CSVFLterm2.getText());

                WebElement CSVFLLimit2 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[2]"));
                row.createCell(30).setCellValue(CSVFLLimit2.getText());

                WebElement CSVFLClassCode1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[3]"));
                row.createCell(31).setCellValue(CSVFLClassCode1.getText());

                WebElement CSVFLRateId1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[4]"));
                row.createCell(32).setCellValue(CSVFLRateId1.getText());

                WebElement CSVFLSuggestedRetailPrice1 = driver.findElement(By.xpath("//*[@id='990' or @id = '991' or @id = '992']/td[5]"));
                row.createCell(23).setCellValue(CSVFLSuggestedRetailPrice1.getText());


                CSVFLterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New Window Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='5']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='5']/td[2]"));
                row.createCell(25).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='5']/td[3]"));
                row.createCell(26).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='5']/td[4]"));
                row.createCell(27).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='5']/td[5]"));
                row.createCell(28).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='999' or @id = '1000' or @id = '1001']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice.getText());

                WindowInsuredFLTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();
                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("VSC New Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='66']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='66']/td[2]"));
                row.createCell(25).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='66']/td[3]"));
                row.createCell(26).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='66']/td[4]"));
                row.createCell(27).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='66']/td[5]"));
                row.createCell(28).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice.getText());

                PlatinumNonInsuredTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();
                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("VSC New POS Platinum VSA (TMIS Surety CLP) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id = 'clp']")).click();
                row = sheet.createRow(++lastRow);

                WebElement VSCType = driver.findElement(By.xpath(""));
                row.createCell(25).setCellValue(VSCType.getText());

                WebElement VSClan = driver.findElement(By.xpath(""));
                row.createCell(26).setCellValue(VSClan.getText());

                WebElement VSCProduct = driver.findElement(By.xpath(""));
                row.createCell(27).setCellValue(VSCProduct.getText());

                WebElement VSCPogram = driver.findElement(By.xpath(""));
                row.createCell(28).setCellValue(VSCPogram.getText());

                WebElement VSCterm1 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm1.getText());

                WebElement VSCLimit1 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit1.getText());

                WebElement VSCClassCode = driver.findElement(By.xpath(""));
                row.createCell(31).setCellValue(VSCClassCode.getText());

                WebElement VSCRateId = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId.getText());

                WebElement VSCSuggestedRetailPrice = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice.getText());

                POSDollarTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("VSC New Platinum VSA (TMIC Insured FL) VSA")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//*[@id='127']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='127']/td[2]"));
                row.createCell(25).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='127']/td[3]"));
                row.createCell(26).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='127']/td[4]"));
                row.createCell(27).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='127']/td[5]"));
                row.createCell(28).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='1202']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='1202']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='1202']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='1202']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1202']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice.getText());
                System.out.println();


                PlatinumInsuredFLTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();
                row = sheet.createRow(++lastRow);
                WebElement CSVWFLterm2 = driver.findElement(By.xpath("//*[@id='962']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm2.getText());

                WebElement CSVWFLLimit2 = driver.findElement(By.xpath("//*[@id='962']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit2.getText());

                WebElement CSVWFLClassCode2 = driver.findElement(By.xpath("//*[@id='962']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode2.getText());

                WebElement CSVWFLRateId2 = driver.findElement(By.xpath("//*[@id='962']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId2.getText());

                WebElement CSVWFLSuggestedRetailPrice2 = driver.findElement(By.xpath("//*[@id='962']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice2.getText());
                CSVWFLterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("VSC Used Gold VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();


                driver.findElement(By.xpath("//*[@id='145']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='145']/td[2]"));
                row.createCell(25).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='145']/td[3]"));
                row.createCell(26).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='145']/td[4]"));
                row.createCell(27).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='145']/td[5]"));
                row.createCell(28).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='1187' or @id = '1181' or @id = '1182' or @id = '1180']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice.getText());


                UsedGoldNonInsuredTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("VSC Used Platinum VSA (TMIS Non-Insured) VSA")) {
                SellAnotherContracttoSameCustomer.click();


                driver.findElement(By.xpath("//*[@id='72']")).click();
                row = sheet.createRow(++lastRow);
                WebElement VSCWFLType = driver.findElement(By.xpath("//*[@id='72']/td[2]"));
                row.createCell(25).setCellValue(VSCWFLType.getText());

                WebElement CSVWFLPlan = driver.findElement(By.xpath("//*[@id='72']/td[3]"));
                row.createCell(26).setCellValue(CSVWFLPlan.getText());

                WebElement CVSWFLProduct = driver.findElement(By.xpath("//*[@id='72']/td[4]"));
                row.createCell(27).setCellValue(CVSWFLProduct.getText());

                WebElement CSVWFLPogram = driver.findElement(By.xpath("//*[@id='72']/td[5]"));
                row.createCell(28).setCellValue(CSVWFLPogram.getText());

                WebElement CSVWFLterm1 = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[1]"));
                row.createCell(29).setCellValue(CSVWFLterm1.getText());

                WebElement CSVWFLLimit1 = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[2]"));
                row.createCell(30).setCellValue(CSVWFLLimit1.getText());

                WebElement CSVWFLClassCode = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[3]"));
                row.createCell(31).setCellValue(CSVWFLClassCode.getText());

                WebElement CSVWFLRateId = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[4]"));
                row.createCell(32).setCellValue(CSVWFLRateId.getText());

                WebElement CSVWFLSuggestedRetailPrice = driver.findElement(By.xpath("//*[@id='938' or @id = '939' or @id = '937']/td[5]"));
                row.createCell(33).setCellValue(CSVWFLSuggestedRetailPrice.getText());

                UsedPlatinumNonInsuredTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

                SellAnotherContracttoSameCustomer.click();

                row = sheet.createRow(++lastRow);
                WebElement VSCterm2 = driver.findElement(By.xpath(""));
                row.createCell(29).setCellValue(VSCterm2.getText());

                WebElement VSCLimit2 = driver.findElement(By.xpath(""));
                row.createCell(30).setCellValue(VSCLimit2.getText());

                WebElement VSCClassCode2 = driver.findElement(By.xpath("]"));
                row.createCell(31).setCellValue(VSCClassCode2.getText());

                WebElement VSCRateId2 = driver.findElement(By.xpath(""));
                row.createCell(32).setCellValue(VSCRateId2.getText());

                WebElement VSCSuggestedRetailPrice2 = driver.findElement(By.xpath(""));
                row.createCell(33).setCellValue(VSCSuggestedRetailPrice2.getText());

                VSCterm2.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    @FindBy(xpath = "//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")
    WebElement BalloonLiabilityTerm1;
    @FindBy(xpath = "//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153']/td[1]")
    WebElement BalloonCreditLIneNYTerm1;
    @FindBy(xpath = "//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '69' or @id = '67']/td[1]")
    WebElement RetailLiabilityTerm1;
    @FindBy(xpath = "//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")
    WebElement LeaseCreditLIneNYTerm1;
    @FindBy(xpath = "//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[1]")
    WebElement RetailCreditLIneNYTerm1;
    @FindBy(xpath = "//tr[@id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[1]")
    WebElement LeaseLiabilityTerm1;
    @FindBy(xpath = "//tr[@id = '493'or @id = '494' or @id ='495' or @id = '492']/td[1]")
    WebElement LeaseUsedLiabilityTerm1;
    @FindBy(xpath = "//*[@id='981' or @id = '982' or @id = '983']/td[1]")
    WebElement RetailUsedLiabilityTerm1;
    @FindBy(xpath = "//*[@id='999' or @id = '1000' or @id = '1001']/td[1]")
    WebElement BalloonCasualtyTerm1;
    @FindBy(xpath = "//*[@id='904' or @id = '453' or @id = '455' or @id = '906']/td[1]")
    WebElement RetailCasualtyTerm1;
    @FindBy(xpath = "//*[@id='904']/td[1]")
    WebElement LeaseNewCasualtyTerm1;
    public void getGAP() throws InterruptedException {
        for (String plans : PlanTypes) {
            System.out.println("GAP: " + plans);
            if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='135' or @id = '120']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPType = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[2]"));
                row.createCell(25).setCellValue(GAPType.getText());

                WebElement GAPPlan = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[3]"));
                row.createCell(26).setCellValue(GAPPlan.getText());

                WebElement GAPProduct = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[4]"));
                row.createCell(27).setCellValue(GAPProduct.getText());

                WebElement GAPPogram = driver.findElement(By.xpath("//tr[@id = '135'or @id = '120']/td[5]"));
                row.createCell(28).setCellValue(GAPPogram.getText());

                WebElement GAPterm1 = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[1]"));
                row.createCell(29).setCellValue(GAPterm1.getText());

                WebElement GAPLimit1 = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[2]"));
                row.createCell(30).setCellValue(GAPLimit1.getText());

                WebElement GAPClassCode = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[3]"));
                row.createCell(31).setCellValue(GAPClassCode.getText());

                WebElement GAPRateId = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[4]"));
                row.createCell(32).setCellValue(GAPRateId.getText());

                WebElement GAPSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1174' or @id = '172' or @id = '173' or @id = '174' or @id = '176' or @id = '175' or @id = '170' or @id = '171' or @id = '131' or @id = '133' or @id = '134' or @id = '129' or @id = '132' or @id = '128']/td[5]"));
                row.createCell(33).setCellValue(GAPSuggestedRetailPrice.getText());
                BalloonLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();

            } else if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='133']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPType = driver.findElement(By.xpath("//tr[@id = '133']/td[2]"));
                row.createCell(25).setCellValue(GAPType.getText());

                WebElement GAPPlan = driver.findElement(By.xpath("//tr[@id = '133']/td[3]"));
                row.createCell(26).setCellValue(GAPPlan.getText());

                WebElement GAPProduct = driver.findElement(By.xpath("//tr[@id = '133']/td[4]"));
                row.createCell(27).setCellValue(GAPProduct.getText());

                WebElement GAPPogram = driver.findElement(By.xpath("//tr[@id = '133']/td[5]"));
                row.createCell(28).setCellValue(GAPPogram.getText());

                WebElement GAPterm1 = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[1]"));
                row.createCell(29).setCellValue(GAPterm1.getText());

                WebElement GAPLimit1 = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[2]"));
                row.createCell(30).setCellValue(GAPLimit1.getText());

                WebElement GAPClassCode = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[3]"));
                row.createCell(31).setCellValue(GAPClassCode.getText());

                WebElement GAPRateId = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[4]"));
                row.createCell(32).setCellValue(GAPRateId.getText());

                WebElement GAPSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1159' or @id = '1164' or @id = '1161' or @id = '1163' or @id = '1165' or @id = '1162' or @id = '1160']/td[5]"));
                row.createCell(33).setCellValue(GAPSuggestedRetailPrice.getText());
                BalloonCreditLIneNYTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail New GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='118']")).click();
                row = sheet.createRow(++lastRow);

                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='118' or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='118'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '181'or @id = '179' or @id ='178' or @id = '180' or @id = '183' or @id = '177' or @id = '182' or @id = '70' or @id = '69' or @id = '67']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());

                RetailLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("GAP Lease New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '134']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='134']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='134']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='134']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='134']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1167' or @id = '1170' or @id = '1166' or @id = '1168' or @id = '1169']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                LeaseCreditLIneNYTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();


            } else if (plans.equalsIgnoreCase("GAP Retail New & Used GAP (TMIC Credit LIne - NY) GAP")) {
                SellAnotherContracttoSameCustomer.click();

                driver.findElement(By.xpath("//tr[@id = '135']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '1174' or @id = '1179' or @id = '1178']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                RetailCreditLIneNYTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease New GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '9' or @id = '13']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());

                LeaseLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease Used GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116' or @id = '117']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '117']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '163' or @id = '164' or @id = '167' or @id = '166' or @id = '165' or @id = '108' or @id = '111' or @id = '107' or @id = '110']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                LeaseUsedLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail Used GAP (TMIC Other Liability) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '135' or @id = '116' or @id = '119']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='135' or @id = '116' or @id = '119']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '1176' or @id = '1177' or @id = '1175' or @id = '1173' or @id = '158' or @id = '156' or @id = '159' or @id = '160' or @id = '157' or @id = '188' or @id = '189' or @id = '187' or @id = '184' or @id = '186' or @id = '190' or @id = '185' or @id = '74' or @id = '73' or @id = '72' or @id = '77' or @id = '75' or @id = '78']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                RetailUsedLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Balloon GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '115']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='115']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='115']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='115']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='115']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '87' or @id = '155' or @id = '153']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                BalloonCasualtyTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Retail New GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '113']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='113']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='113']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='113']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='113']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '55']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '55']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '55']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '55']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '55']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                RetailCasualtyTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("GAP Lease New GAP (TMIC Misc Casualty) GAP")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//tr[@id = '111']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='111']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='111']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='111']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='111']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '37']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '37']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '37']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '37']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '37']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                LeaseNewCasualtyTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    @FindBy(xpath = "//*[@id='1310' or @id = '1311' or @id = '1312' or @id = '1309']/td[1]")
    WebElement ANCNewLeaseLiabilityTerm1;
    @FindBy(xpath = "//tr[@id = '887' or @id = '888' or @id = '889' or @id = '886' or @id = '3153']/td[1]")
    WebElement ANCNewLeaseNonInsuredTerm1;
    @FindBy(xpath = "//*[@id='80' or @id = 'clp']")
    WebElement ANCCertifiedLeaseLiabilityTerm1;
    @FindBy(xpath = "//*[@id='1287' or @id = '1288' or @id = '1289' or @id = '1286']/td[1]")
    WebElement ANCCertifiedLeaseNonInsuredTerm1;
    public void getANC() {
        for (String plans : PlanTypes) {
            System.out.println("ANC: " + plans);
            if (plans.equalsIgnoreCase("ANC New Lease EWU (TMIC Other Liability) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='16']")).click();
                row = sheet.createRow(++lastRow);

                WebElement ANCType = driver.findElement(By.xpath("//tr[@id = '16']/td[2]"));
                row.createCell(25).setCellValue(ANCType.getText());

                WebElement ANCPlan = driver.findElement(By.xpath("//tr[@id = '16']/td[3]"));
                row.createCell(26).setCellValue(ANCPlan.getText());

                WebElement ANCProduct = driver.findElement(By.xpath("//tr[@id = '16']/td[4]"));
                row.createCell(27).setCellValue(ANCProduct.getText());

                WebElement ANCPogram = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(28).setCellValue(ANCPogram.getText());

                WebElement ANCterm1 = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(29).setCellValue(ANCterm1.getText());

                WebElement ANCLimit1 = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(30).setCellValue(ANCLimit1.getText());

                WebElement ANCClassCode = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(31).setCellValue(ANCClassCode.getText());

                WebElement ANCRateId = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(32).setCellValue(ANCRateId.getText());

                WebElement ANCSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '16']/td[5]"));
                row.createCell(33).setCellValue(ANCSuggestedRetailPrice.getText());
                System.out.println();
                ANCNewLeaseLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC New Lease EWU (TMIS Non-Insured) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='6']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='6']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='6']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='6']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='6']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '411' or @id = '414' or @id = '410' or @id = '412' or @id = '413']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                ANCNewLeaseNonInsuredTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC Certified Lease EWU (TMIC Other Liability) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='19']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='19']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='19']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='19']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='19']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '395' or @id = '399' or @id = '396' or @id = '397' or @id = '398']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                ANCCertifiedLeaseLiabilityTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            } else if (plans.equalsIgnoreCase("ANC Certified Lease EWU (TMIS Non-Insured) EWU")) {
                SellAnotherContracttoSameCustomer.click();
                driver.findElement(By.xpath("//*[@id='7']")).click();
                row = sheet.createRow(++lastRow);
                WebElement GAPRType = driver.findElement(By.xpath("//*[@id='7']/td[2]"));
                row.createCell(25).setCellValue(GAPRType.getText());

                WebElement GAPRPlan = driver.findElement(By.xpath("//*[@id='7']/td[3]"));
                row.createCell(26).setCellValue(GAPRPlan.getText());

                WebElement GAPRProduct = driver.findElement(By.xpath("//*[@id='7']/td[4]"));
                row.createCell(27).setCellValue(GAPRProduct.getText());

                WebElement GAPRPogram = driver.findElement(By.xpath("//*[@id='7']/td[5]"));
                row.createCell(28).setCellValue(GAPRPogram.getText());


                WebElement GAPRterm1 = driver.findElement(By.xpath("//tr[@id = '405']/td[1]"));
                row.createCell(29).setCellValue(GAPRterm1.getText());

                WebElement GAPRLimit1 = driver.findElement(By.xpath("//tr[@id = '405']/td[2]"));
                row.createCell(30).setCellValue(GAPRLimit1.getText());

                WebElement GAPRClassCode = driver.findElement(By.xpath("//tr[@id = '405']/td[3]"));
                row.createCell(31).setCellValue(GAPRClassCode.getText());

                WebElement GAPRRateId = driver.findElement(By.xpath("//tr[@id = '405']/td[4]"));
                row.createCell(32).setCellValue(GAPRRateId.getText());

                WebElement GAPRSuggestedRetailPrice = driver.findElement(By.xpath("//tr[@id = '405']/td[5]"));
                row.createCell(33).setCellValue(GAPRSuggestedRetailPrice.getText());
                ANCCertifiedLeaseNonInsuredTerm1.click();
                deductibleInput.click();
                EntercontractAndFinalize.click();
                getdublicatecontract();
            }

        }
    }

    public void getSellContractforNewCustomer() {
        SellContractforNewCustomer.click();
    }

    public void CloseExcel() throws Exception {
        inputStream.close();
        FileOutputStream outFile = new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));

        workbook.write(outFile);
        outFile.close();
        System.out.println("Excel is successfully written");
    }
}

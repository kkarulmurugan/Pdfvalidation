package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FindContract extends TestBase {

    public FindContract() throws Exception {
        PageFactory.initElements(driver, this);
    }


    @FindBy(xpath = "//*[. = 'Find Contract']")
    WebElement FindContracts;

    public void getFindContract() {
        FindContracts.click();

    }

    @FindBy(xpath = "//input[contains(@id,'last6_')]")
    WebElement VehicleVIN;

    public void getVehicleVIN(String VIN) {
        VehicleVIN.sendKeys(VIN);
        VehicleVIN.sendKeys(Keys.ENTER);
    }

    @FindBy(xpath = "//option[.='1000']")
    WebElement Show1000options;

    public void getShow1000options() {
        Show1000options.click();
    }


    //AllcreatedContracts=   driver.findElements(By.xpath("//table[contains(@id,'grid_')]/tbody//tr"));

    public void getVINandContractNum() throws Exception {


        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheetAt(1);
        int lastRow = sheet.getLastRowNum();
        Row row = sheet.createRow(++lastRow);

        List<WebElement> contractsCreated = new ArrayList<>();
        contractsCreated = driver.findElements(By.xpath("//table[contains(@id,'grid_')]/tbody//tr"));

        int contractsCreatedNum = contractsCreated.size();

        for (int i = 2; i < 10; i++) {

            row = sheet.createRow(++lastRow);
            String vin1 = "//table[contains(@id,'grid_')]/tbody//tr[";
            String vin2 = "]//td[25]";
            String vin = vin1 + i + vin2;
            WebElement VinNumbers = driver.findElement(By.xpath(vin));
            row.createCell(0).setCellValue(VinNumbers.getText());

            String ContNum1 = "//table[contains(@id,'grid_')]/tbody//tr[";
            String ContNum2 = "]//td[18]";
            String ContNum = ContNum1 + i + ContNum2;
            WebElement ContractNumbers = driver.findElement(By.xpath(ContNum));
            row.createCell(1).setCellValue(ContractNumbers.getText());
        }


        inputStream.close();
        FileOutputStream outFile = new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));

        workbook.write(outFile);
        outFile.close();
        System.out.println(" is successfully written");


    }


}

package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class InforcePage extends TestBase {

    public FileInputStream inputStream;
    public XSSFWorkbook workbook;
    public Row row;
    public XSSFSheet sheet;
    public int lastRow;

    public void extractDateToExcel() throws Exception {

        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
        inputStream = new FileInputStream(new File(excelFilePath));
        workbook = new XSSFWorkbook(inputStream);
        sheet = workbook.getSheetAt(0);
        lastRow = sheet.getLastRowNum();
        row = sheet.createRow(++lastRow);

//row.createCell(24).setCellValue(PPMSuggestedRetailPrice.getText());
        // row = sheet.createRow(++lastRow);

    }

    public InforcePage() throws Exception {
        PageFactory.initElements(driver, this);
        excel.extractDateToExcel();
    }

    public void CloseExcel() throws Exception {
        inputStream.close();
        FileOutputStream outFile =
                new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));

        workbook.write(outFile);
        outFile.close();
        System.out.println("Excel is successfully written");
    }

    public void getInforce(String dealer) throws Exception {
        WebElement Accounting = driver.findElement(By.xpath("//*[.='Accounting']"));
        Accounting.click();
        WebElement AccountsReceivable = driver.findElement(By.xpath("//*[.='Accounts Receivable']"));
        AccountsReceivable.click();
        Thread.sleep(2000);
        WebElement AccountHolder = driver.findElement(By.xpath("//div[contains(@id,'AccountHolderId_')]/input[2]"));
        AccountHolder.sendKeys(dealer);
        WebElement SelectAccountHolder = driver.findElement(By.xpath("//div[contains(@id,'AccountHolderId_')]/div/div[2]"));
        SelectAccountHolder.click();
        Thread.sleep(2000);
        WebElement ShowBalance = driver.findElement(By.xpath("//*[.='Show Balances']"));
        ShowBalance.click();
        WebElement MFS = driver.findElement(By.xpath("//*[.='MFS']"));
        MFS.click();
        WebElement SelectItemstoReceive = driver.findElement(By.xpath("//*[.='Select Items to Receive']"));
        SelectItemstoReceive.click();
        Thread.sleep(2000);
        WebElement ItemsPerPage = driver.findElement(By.xpath("//*[contains(@id,'pager_')]/table/tbody/tr/td[8]/select"));
        ItemsPerPage.click();
        Thread.sleep(2000);
        WebElement option1000 = driver.findElement(By.xpath("//option[.='1000']"));
        option1000.click();

        WebElement TransectionNumber = driver.findElement(By.xpath("//*[@name = 'TransactionNumber']"));
        TransectionNumber.sendKeys("ietestautomation");
        WebElement datePicker = driver.findElement(By.xpath("//*[@name = 'ModelObject.SentDate']"));
        datePicker.sendKeys("03122020");
        //leave datepicker
        TransectionNumber.click();
        WebElement receivedDate = driver.findElement(By.xpath("//*[@name = 'ModelObject.LedgerDate']"));
        receivedDate.sendKeys("05152021");
        //leave date picker
        TransectionNumber.click();
        Thread.sleep(2000);
        WebElement SelectAll = driver.findElement(By.xpath("//input[@class = 'cbox']"));
        SelectAll.click();
        WebElement SaveReceivable = driver.findElement(By.xpath("//*[.='Save Receivable']"));
        // SaveReceivable.click();

    }

    public void Status() {
        WebElement Contracts = driver.findElement(By.xpath("//*[. = 'Contracts']"));
        Contracts.click();
        WebElement FindContracts = driver.findElement(By.xpath("//*[. = 'Find Contract']"));
        FindContracts.click();


    }
    public void getStatus(String Dealer){
        WebElement dealerName = driver.findElement(By.xpath("//*[@name = 'dealerName']"));
        dealerName.sendKeys("freeman",Keys.ENTER);
        System.out.println(  Dealer );
        for(int i =0;i <4; i++){


        //   //table[contains(@id,'grid_')]//tr[2]//td[18]
        String NumberPart1 = "//table[contains(@id,'grid_')]//tr[";
        String NumberPart2 = "]//td[18]";
        String part = NumberPart1+i+NumberPart2;
        WebElement Number = driver.findElement(By.xpath(part));
            System.out.println(   Number.getText()   );

            String statusPart1 = "//table[contains(@id,'grid_')]//tr[";
            String StatusPart2 = "]//td[20]";
            String statusPart = statusPart1+i+StatusPart2;
            WebElement Status = driver.findElement(By.xpath(part));
            System.out.println(   Status.getText()   );



        }
    }


}

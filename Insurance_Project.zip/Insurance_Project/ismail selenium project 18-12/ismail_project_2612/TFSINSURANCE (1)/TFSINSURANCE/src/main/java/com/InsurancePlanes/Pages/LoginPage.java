package com.InsurancePlanes.Pages;

import com.InsurancePlanes.Base.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends TestBase  {


    //page factory
    @FindBy(xpath = "//input[@id = 'Username']")
    @CacheLookup
    WebElement username;


    @FindBy(id = "Password")
    @CacheLookup
    WebElement password;

    @FindBy(id = "Login_Button")
    WebElement login_Button;

    public LoginPage(){

        PageFactory.initElements(driver, this);
    }

    //actions
    public String validatePageTitle() {

        return driver.getTitle();
    }

    public HomePage getLogin(String un, String psw) throws Exception {

       username.sendKeys(un);
        password.sendKeys(psw);
        login_Button.click();

        return new HomePage();
    }
}

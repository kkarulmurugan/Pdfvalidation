package com.InsurancePlanes.Testdata;

import com.InsurancePlanes.Base.TestBase;
import net.sf.jxls.reader.XLSReadStatus;
import net.sf.jxls.reader.XLSReader;
import net.sf.jxls.reader.XLSSheetReader;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Connection;

import java.io.*;
import java.util.Map;

public class WriteExcel {

    public  FileInputStream inputStream;
    public XSSFWorkbook workbook;
    public Row row;
    public  XSSFSheet sheet;
    public int lastRow;

    public void extractDateToExcel() throws Exception {

        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
        inputStream = new FileInputStream(new File(excelFilePath));
        workbook = new XSSFWorkbook(inputStream);
         sheet = workbook.getSheetAt(0);
         lastRow = sheet.getLastRowNum();
        row = sheet.createRow(++lastRow);

//row.createCell(24).setCellValue(PPMSuggestedRetailPrice.getText());
        // row = sheet.createRow(++lastRow);





    }
    public void CloseExcel() throws Exception {
        inputStream.close();
        FileOutputStream outFile = new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));

        workbook.write(outFile);
        outFile.close();
        System.out.println("Excel is successfully written");
    }
}

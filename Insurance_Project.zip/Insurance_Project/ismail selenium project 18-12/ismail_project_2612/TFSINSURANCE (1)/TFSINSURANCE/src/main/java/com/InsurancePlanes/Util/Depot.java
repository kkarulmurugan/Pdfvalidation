package com.InsurancePlanes.Util;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

public class Depot {

//    @FindBy(xpath = "//*[.='Details']/div")
//    WebElement Details;
//    @FindBy(xpath = "//td[.='VIN']/following-sibling::td")
//    WebElement captureVIN;
//    @FindBy(xpath = "//td[.='Contract Number']/following-sibling::td")
//    WebElement capturreContractNumber;
//    @FindBy(xpath = "//td[.='Odometer']/following-sibling::td")
//    WebElement captureOdometer;
//    @FindBy(xpath = "//td[.='Purchase Type']/following-sibling::td")
//    WebElement capturePurchaseType;
//    @FindBy(xpath = "//td[.='Entered Date']/following-sibling::td")
//    WebElement captureEnteredDate;
//    @FindBy(xpath =  "//td[.='In-Service Date']/following-sibling::td")
//    WebElement captureInServiceDate;
//    //    @FindBy(xpath = "//td[.='Finance Amount']/following-sibling::td")
////    WebElement captureFinanceAmount;
//    List<WebElement> captureFinanceAmount = driver.findElements(By.xpath("//td[.='Finance Amount']/following-sibling::td"));
//    @FindBy(xpath = "//td[.='Finance Length']/following-sibling::td")
//    WebElement captureFinanceLength;
//    @FindBy(xpath = "//td[.='Finance Type']/following-sibling::td")
//    WebElement captureFinaceType;
//    @FindBy(xpath = "//td[.='MSPRP/NADA']/following-sibling::td")
//    WebElement captureMSPRP;
//    @FindBy(xpath = "//td[.='Dealer']/following-sibling::td")
//    WebElement captureDealer;
//    @FindBy(xpath = "//td[.='Program']/following-sibling::td")
//    WebElement captureProgram;
//    @FindBy(xpath = "//td[.='Plan']/following-sibling::td")
//    WebElement capturePlan;
//    @FindBy(xpath = "//td[.='Product']/following-sibling::td")
//    WebElement captureProduct;
//    @FindBy(xpath = "//td[.='Limit']/following-sibling::td")
//    WebElement captureLimit;
//    @FindBy(xpath = "//td[.='Class Code']/following-sibling::td")
//    WebElement captureClassCode;
//    @FindBy(xpath = "//td[.='Contract Purchase Price']/following-sibling::td")
//    WebElement capturePurchasePrice;
//
//    public void getDetails() throws Exception {
//
//        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
//        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
//        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
//        XSSFSheet sheet = workbook.getSheetAt(1);
//        int lastRow = sheet.getLastRowNum();
//        Row row = sheet.createRow(++lastRow);
//
//        for (int i = 1; i < 2; i++){
//            Thread.sleep(2000);
//            AllcreatedContracts.get(i).click();
//            Details.click();
//            System.out.println(       captureVIN.getText()                        );
//            row.createCell(0).setCellValue(        captureVIN.getText()                       );
//            row.createCell(1).setCellValue(        capturreContractNumber.getText()            );
//
//        }
//        inputStream.close();
//        FileOutputStream outFile = new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));
//
//        workbook.write(outFile);
//        outFile.close();
//        System.out.println(" is successfully written");
//
//    }
//
//    @FindBy(xpath =  "//span[contains(@id, 'relatedByVin_')]")
//    WebElement viewRelatedContractsByVIN;
//
//    public void getviewRelatedContractsByVIN(){
//
//        List<WebElement> Relatedvins = driver.findElements(By.xpath("//span[contains(@id, 'relatedByVin_')]"));
//        String relatedVinSTr = Relatedvins.get(0).getText();
//        if(relatedVinSTr.equalsIgnoreCase("View Related Contracts by VIN")){
//            viewRelatedContractsByVIN.click();
//        }else{
//            System.out.println("there is no related contracts to this vin number");
//        }
//
//    }
//
//    public void getReletaedDetails() throws Exception {
//        String excelFilePath = "C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx";
//        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
//        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
//        XSSFSheet sheet = workbook.getSheetAt(1);
//        int lastRow = sheet.getLastRowNum();
//        Row row = sheet.createRow(++lastRow);
//        for (int i = 2; i < contractsNum; i++){
//
//
//
//            //maximize the page
//            row = sheet.createRow(++lastRow);
//            System.out.println(       captureVIN.getText()                        );
//            System.out.println(       capturreContractNumber.getText()            );
//            row.createCell(0).setCellValue(        captureVIN.getText()                       );
//            row.createCell(1).setCellValue(        capturreContractNumber.getText()            );
//
//
//
//        }
//        inputStream.close();
//        FileOutputStream outFile = new FileOutputStream(new File("C:\\Users\\ismaile\\Desktop\\Toyota\\ContractDetails.xlsx"));
//
//        workbook.write(outFile);
//        outFile.close();
//        System.out.println(" is successfully written");
//
//    }
//
//    @FindBy(xpath = "//span[@class = 'ui-button-icon ui-icon ui-icon-closethick']")
//    WebElement closeRelatedContrctsByVin;
//    public void getcloseRelatedContrctsByVin(){
//        closeRelatedContrctsByVin.click();
//    }
}

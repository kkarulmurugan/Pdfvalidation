package com.InsurancePlanes.Util;

public class Testutil {

    public static long Page_Load_Time = 30;
    public static long Implicit_Wait = 30;
}

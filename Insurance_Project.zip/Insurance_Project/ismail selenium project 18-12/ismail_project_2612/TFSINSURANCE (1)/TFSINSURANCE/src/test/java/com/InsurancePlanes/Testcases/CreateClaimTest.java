package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.CreateClaimPage;
import com.InsurancePlanes.Pages.CreateContracts;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.LoginPage;
import com.InsurancePlanes.Testdata.ReadExcel;
import com.InsurancePlanes.Testdata.WriteExcel;
import org.testng.annotations.BeforeClass;

public class CreateClaimTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;
    ReadExcel MazdaNewVin;
    CreateContracts createcontracts;
    WriteExcel excel;
    CreateClaimPage createClaimPage;

    public CreateClaimTest(){
        super();
    }

    @BeforeClass
    public void setUp() throws Exception {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));
        createcontracts = new CreateContracts();
        excel = new WriteExcel();
        createClaimPage = new CreateClaimPage();

    }

    public void CreateClaimTestRun(){
        MazdaNewVin = new ReadExcel();

        createClaimPage.createPPMClaim();
    }
}

package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.CreateContracts;
import com.InsurancePlanes.Pages.ExtractData;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.LoginPage;
import com.InsurancePlanes.Testdata.ReadExcel;
import com.InsurancePlanes.Testdata.WriteExcel;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CreateContractsTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;
    ReadExcel MazdaNewVin;
    CreateContracts createcontracts;
    WriteExcel excel;

    public CreateContractsTest(){
        super();

    }

    @BeforeClass
    public void setUp() throws Exception {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));
        createcontracts = new CreateContracts();
        excel = new WriteExcel();

    }


    @Test
    public void CreateContracts() throws Exception {

        MazdaNewVin = new ReadExcel();


        for (int i = 1; i < 142; i++) {
            Thread.sleep(2000);
            createcontracts.getContracts();
            Thread.sleep(2000);
            createcontracts.clickOnQuickRater();
            Thread.sleep(2000);
            createcontracts.extractDateToExcel();
            Thread.sleep(2000);
            createcontracts.VinNumber(MazdaNewVin.ContractCreateData(i,2));
            createcontracts.getOdometer(MazdaNewVin.ContractCreateData(i,3));
            createcontracts.getPurchaseType(MazdaNewVin.ContractCreateData(i,4));
            createcontracts.getPurchaseDate(MazdaNewVin.ContractCreateData(i,5));
            createcontracts.getPurchasePrice(MazdaNewVin.ContractCreateData(i,6));
            createcontracts.getInServiceDate(MazdaNewVin.ContractCreateData(i,7));
            createcontracts.getFinanceAmount(MazdaNewVin.ContractCreateData(i,8));
            createcontracts.getFinanceLength(MazdaNewVin.ContractCreateData(i,10));
            createcontracts.getFinanceType(MazdaNewVin.ContractCreateData(i,9));
            createcontracts.getMSRP(MazdaNewVin.ContractCreateData(i,11));
            createcontracts.getDealer(MazdaNewVin.ContractCreateData(i,12));
            createcontracts.getGetRates();
            createcontracts.programs();


            //ppm
            createcontracts.getPPM();
            createcontracts.getCustomerFirstName(MazdaNewVin.ContractCreateData(i,14));
            createcontracts.getcustomerLastName(MazdaNewVin.ContractCreateData(i,15));
            createcontracts.getCustomerBusinessName(MazdaNewVin.ContractCreateData(i,16));
            createcontracts.getCustomerAddress1(MazdaNewVin.ContractCreateData(i,17));
            createcontracts.getCustomerAddress2(MazdaNewVin.ContractCreateData(i,18));
            createcontracts.getCustomerZip(MazdaNewVin.ContractCreateData(i,19));
            createcontracts.getCustomerPhone(MazdaNewVin.ContractCreateData(i,20));
            createcontracts.getCoBuyerFirstName(MazdaNewVin.ContractCreateData(i,21));
            createcontracts.getCoBuyerLastName(MazdaNewVin.ContractCreateData(i,22));
            createcontracts.getCoBuyerAddressLine1(MazdaNewVin.ContractCreateData(i,23));
            createcontracts.getCoBuyerAddressLine2(MazdaNewVin.ContractCreateData(i,24));
            createcontracts.getCoBuyerZip(MazdaNewVin.ContractCreateData(i,25));
            createcontracts.getCoBuyerPhone(MazdaNewVin.ContractCreateData(i,26));
            createcontracts.getLienHolderName(MazdaNewVin.ContractCreateData(i,27));
            createcontracts.getMFS();
            Thread.sleep(2000);
            createcontracts.getEntercontractAndFinalize();
            Thread.sleep(2000);
            createcontracts.getdublicatecontract();
            Thread.sleep(2000);


            createcontracts.getterm2();

            //VCS
            Thread.sleep(10000);
            createcontracts.getVSC();


            //GAP
            createcontracts.getGAP();

            //ANC
            createcontracts.getANC();




            createcontracts.CloseExcel();













        }
    }
}

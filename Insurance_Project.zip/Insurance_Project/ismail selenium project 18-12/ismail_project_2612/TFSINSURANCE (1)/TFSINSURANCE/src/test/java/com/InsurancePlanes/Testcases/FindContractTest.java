package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.*;
import com.InsurancePlanes.Testdata.ReadExcel;
import com.InsurancePlanes.Testdata.WriteExcel;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class FindContractTest extends TestBase {

    LoginPage loginPage;
    HomePage homePage;
    ReadExcel MazdaNewVin;
    CreateContracts createcontracts;
    Readpdf readpdf;
    FindContract findContract;
    WriteExcel excel;

    public FindContractTest() { super(); }

    @BeforeClass
    public void setUp() throws Exception {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"), prop.getProperty("password"));
        createcontracts = new CreateContracts();
        readpdf = new Readpdf();
        findContract = new FindContract();
        excel = new WriteExcel();


    }
    @Test
    public void setReadpdf() throws Exception {
        MazdaNewVin = new ReadExcel();


        for (int i = 7; i < 142; i++) {
            homePage.getContracts();
            Thread.sleep(2000);
            findContract.getFindContract();
            Thread.sleep(2000);
            findContract.getVehicleVIN(MazdaNewVin.ContractCreateData(i,2));
            Thread.sleep(2000);
            findContract.getShow1000options();
            Thread.sleep(2000);
            findContract.getVINandContractNum();




        }
    }
}

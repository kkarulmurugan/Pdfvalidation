package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.CreateContracts;
import com.InsurancePlanes.Pages.HomePage;
import com.InsurancePlanes.Pages.InforcePage;
import com.InsurancePlanes.Pages.LoginPage;
import com.InsurancePlanes.Testdata.ReadExcel;
import com.InsurancePlanes.Testdata.WriteExcel;
import org.junit.After;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class InforceTest extends TestBase {

    LoginPage loginPage ;
    HomePage homePage;
    ReadExcel readExcel;
    CreateContracts createcontracts;
    WriteExcel excel;
    InforcePage inforcePage;

    public InforceTest (){
        super();

    }

    @BeforeClass
    public void setUp() throws Exception {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"),prop.getProperty("password"));
        createcontracts = new CreateContracts();
        excel = new WriteExcel();
        inforcePage = new InforcePage();
        readExcel = new ReadExcel();

    }

    @Test
    public void Inforce() throws Exception {
        List<String> dealers = new ArrayList<>();

        int DealersNum = 12;    //row.getrow numbers for dealers
        for(int i = 0; i < DealersNum; i++){
            inforcePage.getInforce(        readExcel.Dealers(i,0)       );
        }

        inforcePage.Status();
        for (int i = 0 ;i < DealersNum;i++){
            inforcePage.getStatus(readExcel.Dealers(i,0));
        }

    }

    @AfterClass
    public void teardown() throws InterruptedException {
        if (driver != null) {
            Thread.sleep(60000);
            driver.quit();
        }
    }
}

package com.InsurancePlanes.Testcases;

import com.InsurancePlanes.Base.TestBase;
import com.InsurancePlanes.Pages.*;
import com.InsurancePlanes.Testdata.ReadExcel;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ReadpdfTest extends TestBase {

    LoginPage loginPage;
    HomePage homePage;
    ReadExcel MazdaNewVin;
    CreateContracts createcontracts;
    Readpdf readpdf;

    public ReadpdfTest() {
        super();

    }

    @BeforeClass
    public void setUp() throws Exception {
        initialization();
        loginPage = new LoginPage();
        homePage = loginPage.getLogin(prop.getProperty("username"), prop.getProperty("password"));
        createcontracts = new CreateContracts();
        readpdf = new Readpdf();

    }
@Test
    public void setReadpdf() throws Exception {
        MazdaNewVin = new ReadExcel();


        for (int i = 2; i < 142; i++) {
//            homePage.getContracts();
//            Thread.sleep(2000);
//            readpdf.getFindContract();
//            Thread.sleep(2000);
//            readpdf.getVehicleVIN(MazdaNewVin.ContractCreateData(i,2));
//            Thread.sleep(2000);
//            readpdf.getShow1000options();
//            Thread.sleep(2000);




        }
    }
}

package org.validation;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.Principal;
import java.security.Security;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.itextpdf.text.log.Logger;
import com.itextpdf.text.log.LoggerFactory;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.security.PdfPKCS7;

public class Pdfvalidation {
	static String valid,signedAt,reason,issuerDN,subjectDN,stime;
	 private static final Logger LOGGER = LoggerFactory.getLogger(Pdfvalidation.class);

	    public static final boolean verifySignature(PdfReader pdfReader)
	            throws GeneralSecurityException, IOException {
	        boolean valid = false;
	        AcroFields acroFields = pdfReader.getAcroFields();
	        List<String> signatureNames = acroFields.getSignatureNames();
	        Security.addProvider(new BouncyCastleProvider());
	        if (!signatureNames.isEmpty()) {
	            for (String name : signatureNames) {
	                if (acroFields.signatureCoversWholeDocument(name)) {
	                    PdfPKCS7 pkcs7 = acroFields.verifySignature(name);
	                    valid = pkcs7.verify();
	                    String reason = pkcs7.getReason();
	                    Calendar signedAt = pkcs7.getSignDate();
	                    String stime = signedAt.toString();
	                    java.security.cert.X509Certificate signingCertificate = pkcs7.getSigningCertificate();
	                    Principal issuerDN = signingCertificate.getIssuerDN();
	                    Principal subjectDN = signingCertificate.getSubjectDN();
	                    System.out.println(valid+" "+ " " + signedAt.getTime() + "  "+ reason+ " " + issuerDN + " "+ subjectDN);
	                  
	                    //LOGGER.info("valid = {}, date = {}, reason = '{}', issuer = '{}', subject = '{}'",valid, signedAt.getTime(), reason, issuerDN, subjectDN);
	                    break;
	                }
	            }
	        }
	        return valid;
	    }
	    
	    public  void outputfile() throws IOException {
	    	
	    	XSSFWorkbook wo=new XSSFWorkbook();
	    	XSSFSheet sheet = wo.createSheet("data");
	    	XSSFRow row = sheet.createRow(1);
	    	XSSFCell cell = row.createCell(1);
	    	cell.setCellValue(valid+" "+ " " + stime + "  "+ reason+ " " + issuerDN + " "+ subjectDN);
	    	
	    	FileOutputStream oust=new FileOutputStream("C:\\Users\\arulmua\\Desktop\\Ar\\pdfdata.xlsx");
	    	wo.write(oust);
			

		}

	    private static void validate(String name)
	            throws IOException, GeneralSecurityException {
	        FileInputStream is = new FileInputStream(name);
	        PdfReader reader = new PdfReader(is);
	        boolean ok = verifySignature(reader);
	        Pdfvalidation pd=new Pdfvalidation();
	    	pd.outputfile();
	    	
	        System.out.println("Signature is verified:"+ok);
	    }

	    public static void main(String[] args) throws Exception {
	        validate("C:\\Users\\arulmua\\eclipse-workspace\\arulmurugan\\newpdf validation\\pdf file\\sample01.pdf"); // if placed in resources' root
	    }
}
